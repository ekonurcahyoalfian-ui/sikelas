<?php
session_start();
require_once __DIR__ . '/../includes/config.php';
requireAdmin();
$pageTitle = 'Data Guru';
$activePage = 'guru';
$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = $_POST['act'] ?? '';
    if ($act === 'save') {
        $nama     = trim($_POST['nama'] ?? '');
        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';
        $isWalas  = isset($_POST['is_walas']) ? 1 : 0;
        $kelasWali= $_POST['kelas_wali_id'] ?: null;
        $ttd      = $_POST['ttd'] ?? '';
        $id       = (int)($_POST['id'] ?? 0);
        $mapels   = array_filter(explode(',', $_POST['mapel_ids'] ?? ''));

        if ($nama && $username) {
            if ($id) {
                $sql = 'UPDATE users SET nama=?,username=?,is_walas=?,kelas_wali_id=?,ttd=? WHERE id=?';
                $params = [$nama,$username,$isWalas,$kelasWali,$ttd,$id];
                if ($password) { $sql = 'UPDATE users SET nama=?,username=?,password=?,is_walas=?,kelas_wali_id=?,ttd=? WHERE id=?'; $params = [$nama,$username,password_hash($password,PASSWORD_BCRYPT),$isWalas,$kelasWali,$ttd,$id]; }
                $db->prepare($sql)->execute($params);
            } else {
                $hash = password_hash($password ?: 'guru123', PASSWORD_BCRYPT);
                $db->prepare('INSERT INTO users(nama,username,password,role,is_walas,kelas_wali_id,ttd) VALUES(?,?,?,"guru",?,?,?)')->execute([$nama,$username,$hash,$isWalas,$kelasWali,$ttd]);
                $id = $db->lastInsertId();
            }
            if ($isWalas && $kelasWali) $db->prepare('UPDATE kelas SET wali_kelas_id=? WHERE id=?')->execute([$id,$kelasWali]);
            flash('ok','Data guru berhasil disimpan.');
        }
    } elseif ($act === 'del') {
        $db->prepare('DELETE FROM users WHERE id=? AND role="guru"')->execute([(int)$_POST['id']]);
        flash('ok','Guru berhasil dihapus.');
    }
    header('Location: guru.php'); exit;
}

$guruList  = $db->query("SELECT u.*, k.nama as kelas_nama FROM users u LEFT JOIN kelas k ON k.id=u.kelas_wali_id WHERE u.role='guru' ORDER BY u.nama")->fetchAll();
$kelasList = $db->query('SELECT * FROM kelas ORDER BY nama')->fetchAll();
$mapelList = $db->query('SELECT * FROM mapel ORDER BY nama')->fetchAll();
$editData  = isset($_GET['edit']) ? $db->query("SELECT * FROM users WHERE id=".(int)$_GET['edit'])->fetch() : null;
include __DIR__ . '/../includes/header.php';
$ok = flash('ok');
?>
<?php if ($ok): ?><div class="alert alert-success alert-auto"><i class="fas fa-check-circle"></i> <?= e($ok) ?></div><?php endif; ?>

<div class="page-header">
  <div class="page-header-left"><h1>Data Guru</h1><p>Kelola data guru dan wali kelas</p></div>
  <div class="page-header-right">
    <a href="../api/template_guru.php" class="btn btn-outline"><i class="fas fa-download"></i> Template CSV</a>
    <button class="btn btn-primary" onclick="openModal('modalGuru')"><i class="fas fa-plus"></i> Tambah Guru</button>
  </div>
</div>

<div class="card">
  <div class="table-wrap">
    <table>
      <thead><tr><th>No</th><th>Nama Guru</th><th>Username</th><th>Role</th><th>Wali Kelas</th><th>Aksi</th></tr></thead>
      <tbody>
      <?php foreach ($guruList as $i => $g): ?>
        <tr>
          <td><?= $i+1 ?></td>
          <td>
            <div class="user-cell">
              <div class="avatar avatar-emerald"><?= strtoupper(substr($g['nama'],0,1)) ?></div>
              <div><div class="user-cell-name"><?= e($g['nama']) ?></div></div>
            </div>
          </td>
          <td><code><?= e($g['username']) ?></code></td>
          <td>
            <span class="badge badge-blue">Guru</span>
            <?php if ($g['is_walas']): ?><span class="badge badge-emerald">Wali Kelas</span><?php endif; ?>
          </td>
          <td><?= $g['kelas_nama'] ? 'Kelas '.e($g['kelas_nama']) : '-' ?></td>
          <td>
            <div class="btn-group">
              <a href="guru.php?edit=<?= $g['id'] ?>" class="btn-icon edit"><i class="fas fa-edit"></i></a>
              <form method="POST" style="display:inline" onsubmit="return confirm('Hapus guru ini?')">
                <input type="hidden" name="act" value="del"><input type="hidden" name="id" value="<?= $g['id'] ?>">
                <button class="btn-icon del"><i class="fas fa-trash"></i></button>
              </form>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$guruList): ?><tr><td colspan="6" style="text-align:center;padding:32px;color:var(--slate-400)">Belum ada guru.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Modal -->
<div class="modal-overlay" id="modalGuru">
  <div class="modal modal-lg">
    <div class="modal-header"><span class="modal-title"><?= $editData?'Edit':'Tambah' ?> Guru</span><button class="modal-close" onclick="closeModal('modalGuru')">&times;</button></div>
    <form method="POST">
      <input type="hidden" name="act" value="save"><input type="hidden" name="id" value="<?= $editData['id']??0 ?>">
      <input type="hidden" name="mapel_ids" id="mapel_ids">
      <input type="hidden" name="ttd" id="ttd_guru_hidden">
      <div class="modal-body">
        <div class="form-group"><label class="form-label">Nama Lengkap <span class="req">*</span></label>
          <input type="text" name="nama" class="form-control" value="<?= e($editData['nama']??'') ?>" required></div>
        <div class="form-row">
          <div class="form-group"><label class="form-label">Username <span class="req">*</span></label>
            <input type="text" name="username" class="form-control" value="<?= e($editData['username']??'') ?>" required></div>
          <div class="form-group"><label class="form-label">Password <?= $editData?'(kosongkan jika tidak diubah)':'' ?></label>
            <div class="pass-wrap"><input type="password" name="password" id="passGuru" class="form-control" placeholder="<?= $editData?'Kosongkan jika tidak diubah':'guru123' ?>">
            <button type="button" class="pass-toggle" onclick="togglePass('passGuru',this)"><i class="fas fa-eye"></i></button></div></div>
        </div>
        <div class="form-group">
          <label class="form-label">Mata Pelajaran yang Diampu</label>
          <div class="chip-list" id="mapel_ids_chips">
            <?php foreach ($mapelList as $m): ?>
            <div class="chip <?= '' ?>" data-value="<?= $m['id'] ?>" onclick="toggleChip(this,'mapel_ids')"><?= e($m['nama']) ?></div>
            <?php endforeach; ?>
          </div>
        </div>
        <div class="checkbox-row">
          <input type="checkbox" name="is_walas" id="isWalas" <?= ($editData['is_walas']??0)?'checked':'' ?> onchange="toggleWalasField()">
          <label for="isWalas">Juga sebagai Wali Kelas</label>
        </div>
        <div id="walasField" style="<?= ($editData['is_walas']??0)?'':'display:none' ?>;margin-top:12px">
          <div class="form-group"><label class="form-label">Kelas yang Diwalikan</label>
            <select name="kelas_wali_id" class="form-control">
              <option value="">-- Pilih Kelas --</option>
              <?php foreach ($kelasList as $k): ?>
              <option value="<?= $k['id'] ?>" <?= ($editData['kelas_wali_id']??'')==$k['id']?'selected':'' ?>>Kelas <?= e($k['nama']) ?></option>
              <?php endforeach; ?>
            </select></div>
        </div>
        <div class="form-group">
          <label class="form-label">Tanda Tangan Guru</label>
          <?php if (!empty($editData['ttd'])): ?>
          <div style="margin-bottom:8px"><img src="<?= $editData['ttd'] ?>" class="sig-preview"> <small style="color:var(--slate-400)">TTD tersimpan</small></div>
          <?php endif; ?>
          <div class="sig-wrap"><canvas id="sigGuru" width="500" height="120"></canvas></div>
          <div class="sig-actions">
            <button type="button" onclick="clearSignature('sigGuru','ttd_guru_hidden')" style="background:none;border:none;color:var(--red);cursor:pointer;font-size:12px"><i class="fas fa-trash"></i> Hapus</button>
            <small style="color:var(--slate-400);margin-left:auto">Gambar tanda tangan di atas</small>
          </div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline" onclick="closeModal('modalGuru')">Batal</button>
        <button type="submit" class="btn btn-primary">Simpan</button>
      </div>
    </form>
  </div>
</div>
<script>
function toggleWalasField(){document.getElementById('walasField').style.display=document.getElementById('isWalas').checked?'block':'none';}
document.addEventListener('DOMContentLoaded',function(){initSignaturePad('sigGuru','ttd_guru_hidden');});
</script>
<?php if ($editData): ?><script>openModal('modalGuru');</script><?php endif; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
