<?php
session_start();
require_once __DIR__ . '/../includes/config.php';
requireAdmin();
$pageTitle = 'Dashboard Admin';
$activePage = 'dashboard';
$db = getDB();

$totalKelas   = $db->query('SELECT COUNT(*) FROM kelas')->fetchColumn();
$totalGuru    = $db->query("SELECT COUNT(*) FROM users WHERE role='guru'")->fetchColumn();
$totalSiswa   = $db->query('SELECT COUNT(*) FROM siswa')->fetchColumn();
$totalMapel   = $db->query('SELECT COUNT(*) FROM mapel')->fetchColumn();
$totalJadwal  = $db->query('SELECT COUNT(*) FROM jadwal_pelajaran')->fetchColumn();
$totalPelanggaran = $db->query('SELECT COUNT(*) FROM pelanggaran')->fetchColumn();

$kelasList = $db->query('
  SELECT k.*, u.nama as walas_nama,
    (SELECT COUNT(*) FROM siswa s WHERE s.kelas_id = k.id) as jml_siswa
  FROM kelas k LEFT JOIN users u ON u.id = k.wali_kelas_id
  ORDER BY k.nama
')->fetchAll();

$recentPelanggaran = $db->query('
  SELECT p.*, s.nama as siswa_nama, j.nama as jenis_nama
  FROM pelanggaran p
  JOIN siswa s ON s.id = p.siswa_id
  JOIN jenis_pelanggaran j ON j.id = p.jenis_pelanggaran_id
  ORDER BY p.created_at DESC LIMIT 5
')->fetchAll();

$config = getKonfigurasi();
include __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
  <div class="page-header-left">
    <h1>Dashboard Admin</h1>
    <p><?= e($config['nama_sekolah']) ?> &mdash; TA <?= e($config['tahun_ajaran']) ?> Semester <?= e($config['semester']) ?></p>
  </div>
</div>

<div class="stats-grid">
  <?php foreach ([
    ['Kelas','fas fa-school',$totalKelas,'bg-blue','text-blue'],
    ['Guru','fas fa-chalkboard-teacher',$totalGuru,'bg-emerald','text-emerald'],
    ['Siswa','fas fa-user-graduate',$totalSiswa,'bg-violet','text-violet'],
    ['Mata Pelajaran','fas fa-book',$totalMapel,'bg-amber','text-amber'],
    ['Jadwal','fas fa-calendar-alt',$totalJadwal,'bg-pink','text-pink'],
    ['Pelanggaran','fas fa-exclamation-triangle',$totalPelanggaran,'bg-red','text-red'],
  ] as [$label,$icon,$val,$bg,$tc]): ?>
  <div class="stat-card">
    <div class="stat-icon <?= $bg ?>"><i class="<?= $icon ?> <?= $tc ?>"></i></div>
    <div class="stat-value <?= $tc ?>"><?= $val ?></div>
    <div class="stat-label"><?= $label ?></div>
  </div>
  <?php endforeach; ?>
</div>

<div class="grid-2">
  <!-- Kelas -->
  <div class="card">
    <div class="card-header"><span class="card-title">Ringkasan Kelas</span></div>
    <div class="card-body" style="padding:0">
      <?php if ($kelasList): ?>
      <table>
        <thead><tr><th>Kelas</th><th>Wali Kelas</th><th>Siswa</th></tr></thead>
        <tbody>
        <?php foreach ($kelasList as $k): ?>
          <tr>
            <td><strong><?= e($k['nama']) ?></strong></td>
            <td><?= $k['walas_nama'] ? e($k['walas_nama']) : '<span style="color:#f59e0b">Belum ditentukan</span>' ?></td>
            <td><span class="badge badge-blue"><?= $k['jml_siswa'] ?></span></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
      <?php else: ?>
      <p style="padding:20px;color:var(--slate-400);font-size:13px">Belum ada kelas terdaftar.</p>
      <?php endif; ?>
    </div>
  </div>

  <!-- Pelanggaran terbaru -->
  <div class="card">
    <div class="card-header"><span class="card-title">Pelanggaran Terbaru</span></div>
    <div class="card-body" style="padding:0">
      <?php if ($recentPelanggaran): ?>
      <table>
        <thead><tr><th>Siswa</th><th>Pelanggaran</th><th>Poin</th></tr></thead>
        <tbody>
        <?php foreach ($recentPelanggaran as $p): ?>
          <tr>
            <td><?= e($p['siswa_nama']) ?></td>
            <td><span style="font-size:12px"><?= e($p['jenis_nama']) ?></span></td>
            <td><span class="badge badge-red">-<?= $p['poin_pengurangan'] ?></span></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
      <?php else: ?>
      <p style="padding:20px;color:var(--slate-400);font-size:13px">Belum ada catatan pelanggaran.</p>
      <?php endif; ?>
    </div>
  </div>
</div>

<?php include __DIR__ . '/../includes/footer.php'; ?>
