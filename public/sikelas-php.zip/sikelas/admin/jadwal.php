<?php
session_start();
require_once __DIR__ . '/../includes/config.php';
requireAdmin();
$pageTitle = 'Jadwal Pelajaran';
$activePage = 'jadwal';
$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = $_POST['act'] ?? '';
    if ($act === 'save') {
        $kelasId  = (int)$_POST['kelas_id'];
        $mapelId  = (int)$_POST['mapel_id'];
        $guruId   = (int)$_POST['guru_id'];
        $hari     = $_POST['hari'];
        $mulai    = $_POST['jam_mulai'];
        $selesai  = $_POST['jam_selesai'];
        $id       = (int)($_POST['id'] ?? 0);
        if ($kelasId && $mapelId && $guruId) {
            if ($id) $db->prepare('UPDATE jadwal_pelajaran SET kelas_id=?,mapel_id=?,guru_id=?,hari=?,jam_mulai=?,jam_selesai=? WHERE id=?')->execute([$kelasId,$mapelId,$guruId,$hari,$mulai,$selesai,$id]);
            else $db->prepare('INSERT INTO jadwal_pelajaran(kelas_id,mapel_id,guru_id,hari,jam_mulai,jam_selesai) VALUES(?,?,?,?,?,?)')->execute([$kelasId,$mapelId,$guruId,$hari,$mulai,$selesai]);
            flash('ok','Jadwal berhasil disimpan.');
        }
    } elseif ($act === 'del') {
        $db->prepare('DELETE FROM jadwal_pelajaran WHERE id=?')->execute([(int)$_POST['id']]);
        flash('ok','Jadwal berhasil dihapus.');
    }
    header('Location: jadwal.php'); exit;
}

$filterKelas = $_GET['kelas'] ?? '';
$filterHari  = $_GET['hari'] ?? '';
$sql = 'SELECT j.*,k.nama as kelas_nama,m.nama as mapel_nama,u.nama as guru_nama FROM jadwal_pelajaran j JOIN kelas k ON k.id=j.kelas_id JOIN mapel m ON m.id=j.mapel_id JOIN users u ON u.id=j.guru_id WHERE 1=1';
$params = [];
if ($filterKelas) { $sql .= ' AND j.kelas_id=?'; $params[] = $filterKelas; }
if ($filterHari) { $sql .= ' AND j.hari=?'; $params[] = $filterHari; }
$sql .= ' ORDER BY FIELD(j.hari,"Senin","Selasa","Rabu","Kamis","Jumat","Sabtu"), j.jam_mulai';
$stmt = $db->prepare($sql); $stmt->execute($params);
$jadwalList = $stmt->fetchAll();
$kelasList  = $db->query('SELECT * FROM kelas ORDER BY nama')->fetchAll();
$mapelList  = $db->query('SELECT * FROM mapel ORDER BY nama')->fetchAll();
$guruList   = $db->query("SELECT id,nama FROM users WHERE role='guru' ORDER BY nama")->fetchAll();
$editData   = isset($_GET['edit']) ? $db->query('SELECT * FROM jadwal_pelajaran WHERE id='.(int)$_GET['edit'])->fetch() : null;
$hariList   = ['Senin','Selasa','Rabu','Kamis','Jumat','Sabtu'];
include __DIR__ . '/../includes/header.php';
$ok = flash('ok');
?>
<?php if ($ok): ?><div class="alert alert-success alert-auto"><i class="fas fa-check-circle"></i> <?= e($ok) ?></div><?php endif; ?>

<div class="page-header">
  <div class="page-header-left"><h1>Jadwal Pelajaran</h1><p>Atur jadwal pelajaran setiap kelas</p></div>
  <div class="page-header-right">
    <a href="../api/template_jadwal.php" class="btn btn-outline"><i class="fas fa-download"></i> Template CSV</a>
    <button class="btn btn-primary" onclick="openModal('modalJadwal')"><i class="fas fa-plus"></i> Tambah Jadwal</button>
  </div>
</div>

<form method="GET" class="filter-bar">
  <div class="form-group"><label class="form-label">Kelas</label>
    <select name="kelas" class="form-control">
      <option value="">Semua Kelas</option>
      <?php foreach ($kelasList as $k): ?><option value="<?= $k['id'] ?>" <?= $filterKelas==$k['id']?'selected':'' ?>>Kelas <?= e($k['nama']) ?></option><?php endforeach; ?>
    </select></div>
  <div class="form-group"><label class="form-label">Hari</label>
    <select name="hari" class="form-control">
      <option value="">Semua Hari</option>
      <?php foreach ($hariList as $h): ?><option <?= $filterHari===$h?'selected':'' ?>><?= $h ?></option><?php endforeach; ?>
    </select></div>
  <div class="form-group" style="align-self:flex-end">
    <button type="submit" class="btn btn-outline"><i class="fas fa-filter"></i> Filter</button>
    <a href="jadwal.php" class="btn btn-outline">Reset</a>
  </div>
</form>

<?php
$byHari = [];
foreach ($jadwalList as $j) $byHari[$j['hari']][] = $j;
foreach ($hariList as $hari):
  if (!isset($byHari[$hari])) continue;
?>
<h3 style="font-size:14px;font-weight:600;color:var(--slate-700);margin:20px 0 10px;display:flex;align-items:center;gap:8px">
  <span style="width:8px;height:8px;background:var(--primary);border-radius:50%;display:inline-block"></span><?= $hari ?>
</h3>
<div class="grid-3" style="margin-bottom:8px">
<?php foreach ($byHari[$hari] as $j): ?>
<div class="jadwal-card">
  <div style="display:flex;justify-content:space-between;align-items:flex-start">
    <div class="jadwal-time"><i class="fas fa-clock" style="color:var(--slate-400)"></i> <?= substr($j['jam_mulai'],0,5) ?> &ndash; <?= substr($j['jam_selesai'],0,5) ?></div>
    <div class="btn-group">
      <a href="jadwal.php?edit=<?= $j['id'] ?>" class="btn-icon edit"><i class="fas fa-edit"></i></a>
      <form method="POST" style="display:inline" onsubmit="return confirm('Hapus jadwal?')">
        <input type="hidden" name="act" value="del"><input type="hidden" name="id" value="<?= $j['id'] ?>">
        <button class="btn-icon del"><i class="fas fa-trash"></i></button>
      </form>
    </div>
  </div>
  <div class="jadwal-mapel"><?= e($j['mapel_nama']) ?></div>
  <div class="jadwal-sub">Kelas <?= e($j['kelas_nama']) ?> &mdash; <?= e($j['guru_nama']) ?></div>
</div>
<?php endforeach; ?>
</div>
<?php endforeach; ?>
<?php if (!$jadwalList): ?><div class="card"><div class="card-body" style="text-align:center;color:var(--slate-400)">Belum ada jadwal pelajaran.</div></div><?php endif; ?>

<!-- Modal -->
<div class="modal-overlay" id="modalJadwal">
  <div class="modal">
    <div class="modal-header"><span class="modal-title"><?= $editData?'Edit':'Tambah' ?> Jadwal</span><button class="modal-close" onclick="closeModal('modalJadwal')">&times;</button></div>
    <form method="POST">
      <input type="hidden" name="act" value="save"><input type="hidden" name="id" value="<?= $editData['id']??0 ?>">
      <div class="modal-body">
        <div class="form-group"><label class="form-label">Kelas <span class="req">*</span></label>
          <select name="kelas_id" class="form-control" required>
            <option value="">-- Pilih Kelas --</option>
            <?php foreach ($kelasList as $k): ?><option value="<?= $k['id'] ?>" <?= ($editData['kelas_id']??'')==$k['id']?'selected':'' ?>>Kelas <?= e($k['nama']) ?></option><?php endforeach; ?>
          </select></div>
        <div class="form-group"><label class="form-label">Mata Pelajaran <span class="req">*</span></label>
          <select name="mapel_id" class="form-control" required>
            <option value="">-- Pilih Mapel --</option>
            <?php foreach ($mapelList as $m): ?><option value="<?= $m['id'] ?>" <?= ($editData['mapel_id']??'')==$m['id']?'selected':'' ?>><?= e($m['nama']) ?></option><?php endforeach; ?>
          </select></div>
        <div class="form-group"><label class="form-label">Guru <span class="req">*</span></label>
          <select name="guru_id" class="form-control" required>
            <option value="">-- Pilih Guru --</option>
            <?php foreach ($guruList as $g): ?><option value="<?= $g['id'] ?>" <?= ($editData['guru_id']??'')==$g['id']?'selected':'' ?>><?= e($g['nama']) ?></option><?php endforeach; ?>
          </select></div>
        <div class="form-group"><label class="form-label">Hari</label>
          <select name="hari" class="form-control">
            <?php foreach ($hariList as $h): ?><option <?= ($editData['hari']??'Senin')===$h?'selected':'' ?>><?= $h ?></option><?php endforeach; ?>
          </select></div>
        <div class="form-row">
          <div class="form-group"><label class="form-label">Jam Mulai</label>
            <input type="time" name="jam_mulai" class="form-control" value="<?= $editData['jam_mulai']??'07:00' ?>"></div>
          <div class="form-group"><label class="form-label">Jam Selesai</label>
            <input type="time" name="jam_selesai" class="form-control" value="<?= $editData['jam_selesai']??'07:45' ?>"></div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline" onclick="closeModal('modalJadwal')">Batal</button>
        <button type="submit" class="btn btn-primary">Simpan</button>
      </div>
    </form>
  </div>
</div>
<?php if ($editData): ?><script>openModal('modalJadwal');</script><?php endif; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
