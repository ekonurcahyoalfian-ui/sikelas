<?php
session_start();
require_once __DIR__ . '/../includes/config.php';
requireAdmin();
$pageTitle = 'Manajemen Kelas';
$activePage = 'kelas';
$db = getDB();

// POST handlers
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = $_POST['act'] ?? '';
    if ($act === 'save') {
        $nama = trim($_POST['nama'] ?? '');
        $ta   = trim($_POST['tahun_ajaran'] ?? '');
        $wali = $_POST['wali_kelas_id'] ?: null;
        $id   = (int)($_POST['id'] ?? 0);
        if ($nama) {
            if ($id) {
                $db->prepare('UPDATE kelas SET nama=?,tahun_ajaran=?,wali_kelas_id=? WHERE id=?')->execute([$nama,$ta,$wali,$id]);
                if ($wali) $db->prepare('UPDATE users SET is_walas=1,kelas_wali_id=? WHERE id=?')->execute([$id,$wali]);
            } else {
                $db->prepare('INSERT INTO kelas(nama,tahun_ajaran,wali_kelas_id) VALUES(?,?,?)')->execute([$nama,$ta,$wali]);
                $newId = $db->lastInsertId();
                if ($wali) $db->prepare('UPDATE users SET is_walas=1,kelas_wali_id=? WHERE id=?')->execute([$newId,$wali]);
            }
            flash('ok','Data kelas berhasil disimpan.');
        }
    } elseif ($act === 'del') {
        $db->prepare('DELETE FROM kelas WHERE id=?')->execute([(int)$_POST['id']]);
        flash('ok','Kelas berhasil dihapus.');
    }
    header('Location: kelas.php'); exit;
}

$config = getKonfigurasi();
$kelasList = $db->query('
  SELECT k.*, u.nama as walas_nama,
    (SELECT COUNT(*) FROM siswa s WHERE s.kelas_id=k.id) as jml_siswa
  FROM kelas k LEFT JOIN users u ON u.id=k.wali_kelas_id ORDER BY k.nama
')->fetchAll();
$guruList = $db->query("SELECT id,nama FROM users WHERE role='guru' ORDER BY nama")->fetchAll();
$editData = null;
if (isset($_GET['edit'])) $editData = $db->prepare('SELECT * FROM kelas WHERE id=?')->execute([(int)$_GET['edit']]) ? $db->query('SELECT * FROM kelas WHERE id='.(int)$_GET['edit'])->fetch() : null;

include __DIR__ . '/../includes/header.php';
$ok = flash('ok');
?>
<?php if ($ok): ?><div class="alert alert-success alert-auto"><i class="fas fa-check-circle"></i> <?= e($ok) ?></div><?php endif; ?>

<div class="page-header">
  <div class="page-header-left"><h1>Manajemen Kelas</h1><p>Kelola data kelas sekolah</p></div>
  <div class="page-header-right">
    <button class="btn btn-primary" onclick="openModal('modalKelas')"><i class="fas fa-plus"></i> Tambah Kelas</button>
  </div>
</div>

<div class="grid-3">
<?php foreach ($kelasList as $k): ?>
<div class="card" style="padding:18px">
  <div style="display:flex;justify-content:space-between;align-items:flex-start;margin-bottom:12px">
    <div style="width:44px;height:44px;background:var(--blue-light);border-radius:10px;display:flex;align-items:center;justify-content:center;font-weight:700;color:var(--blue);font-size:16px">
      <?= strtoupper(substr($k['nama'],0,2)) ?>
    </div>
    <div class="btn-group">
      <a href="kelas.php?edit=<?= $k['id'] ?>" onclick="openModal('modalKelas');" class="btn-icon edit" title="Edit"><i class="fas fa-edit"></i></a>
      <form method="POST" style="display:inline" onsubmit="return confirm('Hapus kelas ini?')">
        <input type="hidden" name="act" value="del"><input type="hidden" name="id" value="<?= $k['id'] ?>">
        <button class="btn-icon del" title="Hapus"><i class="fas fa-trash"></i></button>
      </form>
    </div>
  </div>
  <div style="font-weight:700;font-size:16px">Kelas <?= e($k['nama']) ?></div>
  <div style="font-size:12px;color:var(--slate-500)">TA: <?= e($k['tahun_ajaran']) ?></div>
  <div style="margin-top:12px;padding-top:12px;border-top:1px solid var(--slate-100);display:flex;justify-content:space-between;align-items:center">
    <span style="font-size:12px;color:var(--slate-600)"><i class="fas fa-users"></i> <?= $k['jml_siswa'] ?> Siswa</span>
    <span style="font-size:11px;color:var(--slate-500)">Walas: <?= $k['walas_nama'] ? e($k['walas_nama']) : '<span style="color:#f59e0b">Belum</span>' ?></span>
  </div>
</div>
<?php endforeach; ?>
<?php if (!$kelasList): ?><p style="color:var(--slate-400);grid-column:1/-1">Belum ada kelas.</p><?php endif; ?>
</div>

<!-- Modal -->
<div class="modal-overlay" id="modalKelas">
  <div class="modal">
    <div class="modal-header">
      <span class="modal-title"><?= $editData ? 'Edit' : 'Tambah' ?> Kelas</span>
      <button class="modal-close" onclick="closeModal('modalKelas')">&times;</button>
    </div>
    <form method="POST">
      <input type="hidden" name="act" value="save">
      <input type="hidden" name="id" value="<?= $editData['id'] ?? 0 ?>">
      <div class="modal-body">
        <div class="form-group">
          <label class="form-label">Nama Kelas <span class="req">*</span></label>
          <input type="text" name="nama" class="form-control" placeholder="VII A" value="<?= e($editData['nama']??'') ?>" required>
        </div>
        <div class="form-group">
          <label class="form-label">Tahun Ajaran</label>
          <input type="text" name="tahun_ajaran" class="form-control" placeholder="2025/2026" value="<?= e($editData['tahun_ajaran']??$config['tahun_ajaran']) ?>">
        </div>
        <div class="form-group">
          <label class="form-label">Wali Kelas</label>
          <select name="wali_kelas_id" class="form-control">
            <option value="">-- Pilih Wali Kelas --</option>
            <?php foreach ($guruList as $g): ?>
            <option value="<?= $g['id'] ?>" <?= ($editData['wali_kelas_id']??'')==$g['id']?'selected':'' ?>><?= e($g['nama']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline" onclick="closeModal('modalKelas')">Batal</button>
        <button type="submit" class="btn btn-primary">Simpan</button>
      </div>
    </form>
  </div>
</div>
<?php if ($editData): ?><script>openModal('modalKelas');</script><?php endif; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
