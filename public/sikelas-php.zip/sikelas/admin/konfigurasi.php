<?php
session_start();
require_once __DIR__ . '/../includes/config.php';
requireAdmin();
$pageTitle = 'Konfigurasi';
$activePage = 'konfigurasi';
$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = $_POST['act'] ?? '';
    if ($act === 'sekolah') {
        $db->prepare('UPDATE konfigurasi SET nama_sekolah=?,alamat_sekolah=?,nama_kepsek=?,tahun_ajaran=?,semester=?,ttd_kepsek=? WHERE id=1')
           ->execute([$_POST['nama_sekolah'],$_POST['alamat_sekolah'],$_POST['nama_kepsek'],$_POST['tahun_ajaran'],$_POST['semester'],$_POST['ttd_kepsek']]);
        flash('ok','Konfigurasi sekolah berhasil disimpan.');
    } elseif ($act === 'password') {
        $passLama  = $_POST['password_lama'] ?? '';
        $passBaru  = $_POST['password_baru'] ?? '';
        $konfirmasi= $_POST['konfirmasi'] ?? '';
        $admin = $db->query("SELECT * FROM users WHERE role='admin' AND username='admin' LIMIT 1")->fetch();
        if (!$admin || !password_verify($passLama, $admin['password'])) {
            flash('err_pass','Password lama tidak sesuai.');
        } elseif (strlen($passBaru) < 6) {
            flash('err_pass','Password baru minimal 6 karakter.');
        } elseif ($passBaru !== $konfirmasi) {
            flash('err_pass','Konfirmasi password tidak cocok.');
        } else {
            $db->prepare('UPDATE users SET password=? WHERE id=?')->execute([password_hash($passBaru,PASSWORD_BCRYPT),$admin['id']]);
            flash('ok_pass','Password berhasil diubah.');
        }
    }
    header('Location: konfigurasi.php'); exit;
}

$config = getKonfigurasi();
include __DIR__ . '/../includes/header.php';
$ok = flash('ok'); $okPass = flash('ok_pass'); $errPass = flash('err_pass');
?>
<?php if ($ok): ?><div class="alert alert-success alert-auto"><i class="fas fa-check-circle"></i> <?= e($ok) ?></div><?php endif; ?>

<div class="page-header">
  <div class="page-header-left"><h1>Konfigurasi</h1><p>Pengaturan data sekolah dan akun admin</p></div>
</div>

<div style="display:grid;gap:24px;max-width:720px">

<!-- Konfigurasi Sekolah -->
<div class="card">
  <div class="card-header">
    <span class="card-title"><span style="display:inline-block;width:4px;height:18px;background:var(--primary);border-radius:2px;margin-right:8px;vertical-align:middle"></span>Data Sekolah</span>
  </div>
  <div class="card-body">
    <form method="POST">
      <input type="hidden" name="act" value="sekolah">
      <input type="hidden" name="ttd_kepsek" id="ttd_kepsek_hidden" value="<?= e($config['ttd_kepsek']??'') ?>">
      <div class="form-group"><label class="form-label">Nama Sekolah</label>
        <input type="text" name="nama_sekolah" class="form-control" value="<?= e($config['nama_sekolah']) ?>"></div>
      <div class="form-group"><label class="form-label">Alamat Sekolah</label>
        <textarea name="alamat_sekolah" class="form-control" rows="2"><?= e($config['alamat_sekolah']) ?></textarea></div>
      <div class="form-row">
        <div class="form-group"><label class="form-label">Tahun Ajaran</label>
          <input type="text" name="tahun_ajaran" class="form-control" value="<?= e($config['tahun_ajaran']) ?>"></div>
        <div class="form-group"><label class="form-label">Semester</label>
          <select name="semester" class="form-control">
            <option <?= $config['semester']==='Ganjil'?'selected':'' ?>>Ganjil</option>
            <option <?= $config['semester']==='Genap'?'selected':'' ?>>Genap</option>
          </select></div>
      </div>
      <div class="form-group"><label class="form-label">Nama Kepala Sekolah</label>
        <input type="text" name="nama_kepsek" class="form-control" value="<?= e($config['nama_kepsek']) ?>"></div>
      <div class="form-group">
        <label class="form-label">Tanda Tangan Kepala Sekolah</label>
        <?php if (!empty($config['ttd_kepsek'])): ?>
        <div style="margin-bottom:8px"><img src="<?= $config['ttd_kepsek'] ?>" class="sig-preview" style="max-height:60px"> <small style="color:var(--slate-400)">TTD tersimpan</small></div>
        <?php endif; ?>
        <div class="sig-wrap"><canvas id="sigKepsek" width="500" height="120"></canvas></div>
        <div class="sig-actions">
          <button type="button" onclick="clearSignature('sigKepsek','ttd_kepsek_hidden')" style="background:none;border:none;color:var(--red);cursor:pointer;font-size:12px"><i class="fas fa-trash"></i> Hapus</button>
          <small style="color:var(--slate-400);margin-left:auto">Gambar tanda tangan di atas</small>
        </div>
      </div>
      <button type="submit" class="btn btn-primary"><i class="fas fa-save"></i> Simpan Konfigurasi</button>
    </form>
  </div>
</div>

<!-- Ganti Password -->
<div class="card">
  <div class="card-header">
    <span class="card-title"><span style="display:inline-block;width:4px;height:18px;background:var(--blue);border-radius:2px;margin-right:8px;vertical-align:middle"></span><i class="fas fa-shield-alt" style="color:var(--blue);margin-right:6px"></i>Ganti Password Admin</span>
  </div>
  <div class="card-body">
    <?php if ($okPass): ?><div class="alert alert-success alert-auto"><i class="fas fa-check-circle"></i> <?= e($okPass) ?></div><?php endif; ?>
    <?php if ($errPass): ?><div class="alert alert-error"><i class="fas fa-times-circle"></i> <?= e($errPass) ?></div><?php endif; ?>
    <div style="padding:10px 14px;background:var(--slate-50);border-radius:8px;font-size:13px;color:var(--slate-600);margin-bottom:16px;display:flex;align-items:center;gap:8px">
      <i class="fas fa-key" style="color:var(--slate-400)"></i>
      Akun: <strong style="font-family:monospace">admin</strong>
    </div>
    <form method="POST">
      <input type="hidden" name="act" value="password">
      <div class="form-group"><label class="form-label">Password Lama <span class="req">*</span></label>
        <div class="pass-wrap">
          <input type="password" name="password_lama" id="passLama" class="form-control" placeholder="Masukkan password saat ini" required>
          <button type="button" class="pass-toggle" onclick="togglePass('passLama',this)"><i class="fas fa-eye"></i></button>
        </div></div>
      <div class="form-group"><label class="form-label">Password Baru <span class="req">*</span></label>
        <div class="pass-wrap">
          <input type="password" name="password_baru" id="password_baru" class="form-control" placeholder="Minimal 6 karakter" required>
          <button type="button" class="pass-toggle" onclick="togglePass('password_baru',this)"><i class="fas fa-eye"></i></button>
        </div></div>
      <div class="form-group"><label class="form-label">Konfirmasi Password Baru <span class="req">*</span></label>
        <div class="pass-wrap">
          <input type="password" name="konfirmasi" id="konfirmasi" class="form-control" placeholder="Ulangi password baru" onkeyup="checkConfirmPass()" required>
          <button type="button" class="pass-toggle" onclick="togglePass('konfirmasi',this)"><i class="fas fa-eye"></i></button>
        </div>
        <div id="pass_match_msg" style="font-size:12px;margin-top:4px"></div>
      </div>
      <button type="submit" class="btn btn-blue"><i class="fas fa-key"></i> Ubah Password</button>
    </form>
  </div>
</div>

</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
  initSignaturePad('sigKepsek', 'ttd_kepsek_hidden');
});
</script>
<?php include __DIR__ . '/../includes/footer.php'; ?>
