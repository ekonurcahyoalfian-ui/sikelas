<?php
session_start();
require_once __DIR__ . '/../includes/config.php';
requireAdmin();
$pageTitle = 'Mata Pelajaran';
$activePage = 'mapel';
$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = $_POST['act'] ?? '';
    if ($act === 'save') {
        $nama = trim($_POST['nama'] ?? '');
        $kode = trim($_POST['kode'] ?? '');
        $jp   = (int)($_POST['jp_per_pekan'] ?? 2);
        $id   = (int)($_POST['id'] ?? 0);
        if ($nama) {
            if ($id) $db->prepare('UPDATE mapel SET nama=?,kode=?,jp_per_pekan=? WHERE id=?')->execute([$nama,$kode,$jp,$id]);
            else $db->prepare('INSERT INTO mapel(nama,kode,jp_per_pekan) VALUES(?,?,?)')->execute([$nama,$kode,$jp]);
            flash('ok','Mata pelajaran berhasil disimpan.');
        }
    } elseif ($act === 'del') {
        $db->prepare('DELETE FROM mapel WHERE id=?')->execute([(int)$_POST['id']]);
        flash('ok','Mata pelajaran berhasil dihapus.');
    } elseif ($act === 'import') {
        // Import CSV/Excel (simplified CSV import)
        if (isset($_FILES['file']) && $_FILES['file']['error']===0) {
            $ext = strtolower(pathinfo($_FILES['file']['name'], PATHINFO_EXTENSION));
            if (in_array($ext,['csv'])) {
                $rows = array_map('str_getcsv', file($_FILES['file']['tmp_name']));
                $header = array_shift($rows);
                $cnt = 0;
                foreach ($rows as $row) {
                    if (count($row) < 1) continue;
                    $nama = trim($row[0] ?? ''); $kode = trim($row[1] ?? ''); $jp = (int)($row[2] ?? 2);
                    if (!$nama) continue;
                    $db->prepare('INSERT IGNORE INTO mapel(nama,kode,jp_per_pekan) VALUES(?,?,?)')->execute([$nama,$kode,$jp]);
                    $cnt++;
                }
                flash('ok',"Berhasil import $cnt mata pelajaran.");
            } else flash('err','Hanya file CSV yang didukung untuk import.');
        }
    }
    header('Location: mapel.php'); exit;
}

$mapelList = $db->query('SELECT * FROM mapel ORDER BY nama')->fetchAll();
$editData  = isset($_GET['edit']) ? $db->query('SELECT * FROM mapel WHERE id='.(int)$_GET['edit'])->fetch() : null;
include __DIR__ . '/../includes/header.php';
$ok = flash('ok'); $err = flash('err');
?>
<?php if ($ok): ?><div class="alert alert-success alert-auto"><i class="fas fa-check-circle"></i> <?= e($ok) ?></div><?php endif; ?>
<?php if ($err): ?><div class="alert alert-error"><i class="fas fa-times-circle"></i> <?= e($err) ?></div><?php endif; ?>

<div class="page-header">
  <div class="page-header-left"><h1>Mata Pelajaran</h1><p>Kelola daftar mata pelajaran</p></div>
  <div class="page-header-right">
    <a href="../api/template_mapel.php" class="btn btn-outline"><i class="fas fa-download"></i> Template CSV</a>
    <button class="btn btn-outline" onclick="openModal('modalImport')"><i class="fas fa-upload"></i> Import CSV</button>
    <button class="btn btn-primary" onclick="openModal('modalMapel')"><i class="fas fa-plus"></i> Tambah</button>
  </div>
</div>

<div class="card">
  <div class="table-wrap">
    <table>
      <thead><tr><th>No</th><th>Nama Mata Pelajaran</th><th>Kode</th><th>JP/Pekan</th><th>Aksi</th></tr></thead>
      <tbody>
      <?php foreach ($mapelList as $i => $m): ?>
        <tr>
          <td><?= $i+1 ?></td>
          <td><strong><?= e($m['nama']) ?></strong></td>
          <td><span class="badge badge-blue" style="font-family:monospace"><?= e($m['kode']) ?></span></td>
          <td><?= $m['jp_per_pekan'] ?> JP/Pekan</td>
          <td>
            <div class="btn-group">
              <a href="mapel.php?edit=<?= $m['id'] ?>" class="btn-icon edit"><i class="fas fa-edit"></i></a>
              <form method="POST" style="display:inline" onsubmit="return confirm('Hapus mapel ini?')">
                <input type="hidden" name="act" value="del"><input type="hidden" name="id" value="<?= $m['id'] ?>">
                <button class="btn-icon del"><i class="fas fa-trash"></i></button>
              </form>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$mapelList): ?><tr><td colspan="5" style="text-align:center;padding:32px;color:var(--slate-400)">Belum ada mata pelajaran.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Modal Tambah/Edit -->
<div class="modal-overlay" id="modalMapel">
  <div class="modal">
    <div class="modal-header"><span class="modal-title"><?= $editData?'Edit':'Tambah' ?> Mata Pelajaran</span><button class="modal-close" onclick="closeModal('modalMapel')">&times;</button></div>
    <form method="POST">
      <input type="hidden" name="act" value="save"><input type="hidden" name="id" value="<?= $editData['id']??0 ?>">
      <div class="modal-body">
        <div class="form-group"><label class="form-label">Nama Mata Pelajaran <span class="req">*</span></label>
          <input type="text" name="nama" class="form-control" placeholder="Matematika" value="<?= e($editData['nama']??'') ?>" required></div>
        <div class="form-row">
          <div class="form-group"><label class="form-label">Kode</label>
            <input type="text" name="kode" class="form-control" placeholder="MTK" value="<?= e($editData['kode']??'') ?>"></div>
          <div class="form-group"><label class="form-label">JP/Pekan</label>
            <input type="number" name="jp_per_pekan" class="form-control" min="1" max="20" value="<?= $editData['jp_per_pekan']??2 ?>"></div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline" onclick="closeModal('modalMapel')">Batal</button>
        <button type="submit" class="btn btn-primary">Simpan</button>
      </div>
    </form>
  </div>
</div>

<!-- Modal Import -->
<div class="modal-overlay" id="modalImport">
  <div class="modal">
    <div class="modal-header"><span class="modal-title">Import Mata Pelajaran (CSV)</span><button class="modal-close" onclick="closeModal('modalImport')">&times;</button></div>
    <form method="POST" enctype="multipart/form-data">
      <input type="hidden" name="act" value="import">
      <div class="modal-body">
        <div class="alert alert-info"><i class="fas fa-info-circle"></i> Format CSV: nama, kode, jp_per_pekan. Download template terlebih dahulu.</div>
        <div class="form-group"><label class="form-label">File CSV</label>
          <input type="file" name="file" class="form-control" accept=".csv" required></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline" onclick="closeModal('modalImport')">Batal</button>
        <button type="submit" class="btn btn-primary"><i class="fas fa-upload"></i> Import</button>
      </div>
    </form>
  </div>
</div>
<?php if ($editData): ?><script>openModal('modalMapel');</script><?php endif; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
