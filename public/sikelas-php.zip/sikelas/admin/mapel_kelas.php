<?php
session_start();
require_once __DIR__ . '/../includes/config.php';
requireAdmin();
$pageTitle = 'Mapel per Kelas';
$activePage = 'mapel_kelas';
$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = $_POST['act'] ?? '';
    if ($act === 'save') {
        try {
            $db->prepare('INSERT INTO mapel_kelas(kelas_id,mapel_id,guru_id) VALUES(?,?,?)')->execute([(int)$_POST['kelas_id'],(int)$_POST['mapel_id'],(int)$_POST['guru_id']]);
            flash('ok','Mapel berhasil ditambahkan ke kelas.');
        } catch (Exception $e) { flash('err','Mapel sudah terdaftar di kelas ini.'); }
    } elseif ($act === 'del') {
        $db->prepare('DELETE FROM mapel_kelas WHERE id=?')->execute([(int)$_POST['id']]);
        flash('ok','Mapel berhasil dihapus dari kelas.');
    }
    header('Location: mapel_kelas.php'); exit;
}

$kelasList = $db->query('SELECT * FROM kelas ORDER BY nama')->fetchAll();
$mapelList = $db->query('SELECT * FROM mapel ORDER BY nama')->fetchAll();
$guruList  = $db->query("SELECT id,nama FROM users WHERE role='guru' ORDER BY nama")->fetchAll();
$mkList    = $db->query('SELECT mk.*,k.nama as kelas_nama,m.nama as mapel_nama,u.nama as guru_nama FROM mapel_kelas mk JOIN kelas k ON k.id=mk.kelas_id JOIN mapel m ON m.id=mk.mapel_id JOIN users u ON u.id=mk.guru_id ORDER BY k.nama,m.nama')->fetchAll();
include __DIR__ . '/../includes/header.php';
$ok = flash('ok'); $err = flash('err');
?>
<?php if ($ok): ?><div class="alert alert-success alert-auto"><i class="fas fa-check-circle"></i> <?= e($ok) ?></div><?php endif; ?>
<?php if ($err): ?><div class="alert alert-error"><i class="fas fa-times-circle"></i> <?= e($err) ?></div><?php endif; ?>

<div class="page-header">
  <div class="page-header-left"><h1>Mapel per Kelas</h1><p>Atur mata pelajaran yang diajarkan di setiap kelas</p></div>
  <div class="page-header-right"><button class="btn btn-primary" onclick="openModal('modalMK')"><i class="fas fa-plus"></i> Tambah</button></div>
</div>

<?php
$byKelas = [];
foreach ($mkList as $mk) $byKelas[$mk['kelas_nama']][] = $mk;
foreach ($kelasList as $k):
  $items = $byKelas[$k['nama']] ?? [];
?>
<div class="card" style="margin-bottom:16px">
  <div class="card-header"><span class="card-title">Kelas <?= e($k['nama']) ?></span></div>
  <div class="card-body">
    <?php if ($items): ?>
    <div class="chip-list">
      <?php foreach ($items as $mk): ?>
      <div style="display:inline-flex;align-items:center;gap:8px;padding:6px 12px;background:var(--blue-light);border-radius:20px">
        <div>
          <div style="font-size:13px;font-weight:500;color:var(--blue)"><?= e($mk['mapel_nama']) ?></div>
          <div style="font-size:11px;color:var(--slate-500)"><?= e($mk['guru_nama']) ?></div>
        </div>
        <form method="POST" style="display:inline" onsubmit="return confirm('Hapus?')">
          <input type="hidden" name="act" value="del"><input type="hidden" name="id" value="<?= $mk['id'] ?>">
          <button style="background:none;border:none;color:var(--slate-400);cursor:pointer;font-size:13px">&times;</button>
        </form>
      </div>
      <?php endforeach; ?>
    </div>
    <?php else: ?><p style="color:var(--slate-400);font-size:13px">Belum ada mapel terdaftar.</p><?php endif; ?>
  </div>
</div>
<?php endforeach; ?>

<div class="modal-overlay" id="modalMK">
  <div class="modal">
    <div class="modal-header"><span class="modal-title">Tambah Mapel ke Kelas</span><button class="modal-close" onclick="closeModal('modalMK')">&times;</button></div>
    <form method="POST">
      <input type="hidden" name="act" value="save">
      <div class="modal-body">
        <div class="form-group"><label class="form-label">Kelas</label>
          <select name="kelas_id" class="form-control" required>
            <option value="">-- Pilih Kelas --</option>
            <?php foreach ($kelasList as $k): ?><option value="<?= $k['id'] ?>">Kelas <?= e($k['nama']) ?></option><?php endforeach; ?>
          </select></div>
        <div class="form-group"><label class="form-label">Mata Pelajaran</label>
          <select name="mapel_id" class="form-control" required>
            <option value="">-- Pilih Mapel --</option>
            <?php foreach ($mapelList as $m): ?><option value="<?= $m['id'] ?>"><?= e($m['nama']) ?></option><?php endforeach; ?>
          </select></div>
        <div class="form-group"><label class="form-label">Guru Pengampu</label>
          <select name="guru_id" class="form-control" required>
            <option value="">-- Pilih Guru --</option>
            <?php foreach ($guruList as $g): ?><option value="<?= $g['id'] ?>"><?= e($g['nama']) ?></option><?php endforeach; ?>
          </select></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline" onclick="closeModal('modalMK')">Batal</button>
        <button type="submit" class="btn btn-primary">Simpan</button>
      </div>
    </form>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
