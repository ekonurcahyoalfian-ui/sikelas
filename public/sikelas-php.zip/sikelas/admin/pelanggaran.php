<?php
session_start();
require_once __DIR__ . '/../includes/config.php';
requireAdmin();
$pageTitle = 'Pelanggaran';
$activePage = 'pelanggaran';
$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = $_POST['act'] ?? '';
    if ($act === 'save_jenis') {
        $nama = trim($_POST['nama']??''); $kat = $_POST['kategori']; $poin = (int)$_POST['poin_pengurangan']; $id = (int)($_POST['id']??0);
        if ($nama) {
            if ($id) $db->prepare('UPDATE jenis_pelanggaran SET nama=?,kategori=?,poin_pengurangan=? WHERE id=?')->execute([$nama,$kat,$poin,$id]);
            else $db->prepare('INSERT INTO jenis_pelanggaran(nama,kategori,poin_pengurangan) VALUES(?,?,?)')->execute([$nama,$kat,$poin]);
            flash('ok','Jenis pelanggaran berhasil disimpan.');
        }
    } elseif ($act === 'del_jenis') {
        $db->prepare('DELETE FROM jenis_pelanggaran WHERE id=?')->execute([(int)$_POST['id']]);
        flash('ok','Jenis pelanggaran dihapus.');
    }
    header('Location: pelanggaran.php'); exit;
}

$jenisList = $db->query('SELECT * FROM jenis_pelanggaran ORDER BY kategori,nama')->fetchAll();
$rekapSiswa = $db->query('SELECT s.*,k.nama as kelas_nama, COUNT(p.id) as jml_pelanggaran FROM siswa s LEFT JOIN kelas k ON k.id=s.kelas_id LEFT JOIN pelanggaran p ON p.siswa_id=s.id GROUP BY s.id ORDER BY s.poin ASC')->fetchAll();
$editData = isset($_GET['edit']) ? $db->query('SELECT * FROM jenis_pelanggaran WHERE id='.(int)$_GET['edit'])->fetch() : null;
include __DIR__ . '/../includes/header.php';
$ok = flash('ok');
?>
<?php if ($ok): ?><div class="alert alert-success alert-auto"><i class="fas fa-check-circle"></i> <?= e($ok) ?></div><?php endif; ?>

<div class="page-header">
  <div class="page-header-left"><h1>Pelanggaran Siswa</h1><p>Kelola jenis pelanggaran dan rekap poin</p></div>
  <div class="page-header-right"><button class="btn btn-red" onclick="openModal('modalJenis')"><i class="fas fa-plus"></i> Tambah Jenis</button></div>
</div>

<div id="tabGroup">
<div class="tabs">
  <button class="tab-btn active" data-tab="tabJenis" onclick="switchTab('tabJenis','tabGroup')">Jenis Pelanggaran</button>
  <button class="tab-btn" data-tab="tabRekap" onclick="switchTab('tabRekap','tabGroup')">Rekap Poin Siswa</button>
</div>

<div id="tabJenis" class="tab-pane active">
  <div class="grid-3">
  <?php foreach ($jenisList as $j):
    $bc = $j['kategori']==='Ringan'?'badge-amber':($j['kategori']==='Sedang'?'badge-red':'badge-red');
    $bg = $j['kategori']==='Ringan'?'var(--amber-light)':($j['kategori']==='Sedang'?'#ffe4e6':'#fee2e2');
  ?>
  <div class="card" style="padding:16px">
    <div style="display:flex;justify-content:space-between;margin-bottom:10px">
      <span class="badge <?= $bc ?>"><?= $j['kategori'] ?></span>
      <div class="btn-group">
        <a href="pelanggaran.php?edit=<?= $j['id'] ?>" class="btn-icon edit"><i class="fas fa-edit"></i></a>
        <form method="POST" style="display:inline" onsubmit="return confirm('Hapus?')">
          <input type="hidden" name="act" value="del_jenis"><input type="hidden" name="id" value="<?= $j['id'] ?>">
          <button class="btn-icon del"><i class="fas fa-trash"></i></button>
        </form>
      </div>
    </div>
    <div style="font-size:13px;font-weight:500;color:var(--slate-800);margin-bottom:10px"><?= e($j['nama']) ?></div>
    <div style="display:flex;align-items:center;gap:6px">
      <i class="fas fa-exclamation-triangle" style="color:var(--red);font-size:13px"></i>
      <span style="font-size:22px;font-weight:700;color:var(--red)">-<?= $j['poin_pengurangan'] ?></span>
      <span style="font-size:12px;color:var(--slate-500)">poin</span>
    </div>
  </div>
  <?php endforeach; ?>
  </div>
</div>

<div id="tabRekap" class="tab-pane">
  <div class="card">
    <div class="table-wrap">
      <table>
        <thead><tr><th>Siswa</th><th>Kelas</th><th>Poin</th><th>Jml Pelanggaran</th><th>Status</th></tr></thead>
        <tbody>
        <?php foreach ($rekapSiswa as $s):
          $poinColor = $s['poin']>=80?'badge-emerald':($s['poin']>=60?'badge-amber':'badge-red');
          $status = $s['poin']>=80?'Baik':($s['poin']>=60?'Perlu Perhatian':'Kritis');
          $sc = $s['poin']>=80?'badge-emerald':($s['poin']>=60?'badge-amber':'badge-red');
        ?>
          <tr>
            <td><div class="user-cell"><div class="avatar avatar-violet"><?= strtoupper(substr($s['nama'],0,1)) ?></div><span class="user-cell-name"><?= e($s['nama']) ?></span></div></td>
            <td><?= e($s['kelas_nama']??'-') ?></td>
            <td><span class="badge <?= $poinColor ?>" style="font-size:14px"><?= $s['poin'] ?></span></td>
            <td><?= $s['jml_pelanggaran'] ?>x</td>
            <td><span class="badge <?= $sc ?>"><?= $status ?></span></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
</div>
</div>

<div class="modal-overlay" id="modalJenis">
  <div class="modal">
    <div class="modal-header"><span class="modal-title"><?= $editData?'Edit':'Tambah' ?> Jenis Pelanggaran</span><button class="modal-close" onclick="closeModal('modalJenis')">&times;</button></div>
    <form method="POST">
      <input type="hidden" name="act" value="save_jenis"><input type="hidden" name="id" value="<?= $editData['id']??0 ?>">
      <div class="modal-body">
        <div class="form-group"><label class="form-label">Nama Pelanggaran</label>
          <input type="text" name="nama" class="form-control" value="<?= e($editData['nama']??'') ?>" required></div>
        <div class="form-group"><label class="form-label">Kategori</label>
          <select name="kategori" class="form-control">
            <?php foreach (['Ringan','Sedang','Berat'] as $kat): ?>
            <option <?= ($editData['kategori']??'Ringan')===$kat?'selected':'' ?>><?= $kat ?></option>
            <?php endforeach; ?>
          </select></div>
        <div class="form-group"><label class="form-label">Pengurangan Poin</label>
          <input type="number" name="poin_pengurangan" class="form-control" min="1" max="100" value="<?= $editData['poin_pengurangan']??5 ?>"></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline" onclick="closeModal('modalJenis')">Batal</button>
        <button type="submit" class="btn btn-red">Simpan</button>
      </div>
    </form>
  </div>
</div>
<?php if ($editData): ?><script>openModal('modalJenis');</script><?php endif; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
