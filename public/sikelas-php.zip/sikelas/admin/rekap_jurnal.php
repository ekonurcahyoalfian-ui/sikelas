<?php
session_start();
require_once __DIR__ . '/../includes/config.php';
requireAdmin();
$pageTitle = 'Rekap Jurnal';
$activePage = 'rekap_jurnal';
$db = getDB();

$filterGuru = $_GET['guru'] ?? '';
$tglMulai   = $_GET['tgl_mulai'] ?? date('Y-m-01');
$tglSelesai = $_GET['tgl_selesai'] ?? date('Y-m-d');
$guruList   = $db->query("SELECT id,nama FROM users WHERE role='guru' ORDER BY nama")->fetchAll();
$targetGurus = $filterGuru ? $db->query("SELECT id,nama FROM users WHERE id=".(int)$filterGuru)->fetchAll() : $guruList;
include __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
  <div class="page-header-left"><h1>Rekap Jurnal Mengajar</h1><p>Download rekap jurnal per guru</p></div>
</div>

<div class="card" style="margin-bottom:20px">
  <div class="card-body">
    <form method="GET" class="filter-bar">
      <div class="form-group"><label class="form-label">Guru</label>
        <select name="guru" class="form-control">
          <option value="">Semua Guru</option>
          <?php foreach ($guruList as $g): ?><option value="<?= $g['id'] ?>" <?= $filterGuru==$g['id']?'selected':'' ?>><?= e($g['nama']) ?></option><?php endforeach; ?>
        </select></div>
      <div class="form-group"><label class="form-label">Dari</label><input type="date" name="tgl_mulai" class="form-control" value="<?= $tglMulai ?>"></div>
      <div class="form-group"><label class="form-label">Sampai</label><input type="date" name="tgl_selesai" class="form-control" value="<?= $tglSelesai ?>"></div>
      <div class="form-group" style="align-self:flex-end"><button type="submit" class="btn btn-outline"><i class="fas fa-filter"></i> Filter</button></div>
    </form>
  </div>
</div>

<div class="card">
  <div class="table-wrap">
    <table>
      <thead><tr><th>Guru</th><th>Jml Jurnal</th><th>Download</th></tr></thead>
      <tbody>
      <?php foreach ($targetGurus as $g):
        $jmlJurnal = $db->prepare('SELECT COUNT(*) FROM jurnal_mengajar jm JOIN jadwal_pelajaran jp ON jp.id=jm.jadwal_id WHERE jp.guru_id=? AND jm.tanggal BETWEEN ? AND ?');
        $jmlJurnal->execute([$g['id'],$tglMulai,$tglSelesai]);
        $cnt = $jmlJurnal->fetchColumn();
      ?>
        <tr>
          <td><div class="user-cell"><div class="avatar avatar-emerald"><?= strtoupper(substr($g['nama'],0,1)) ?></div><span class="user-cell-name"><?= e($g['nama']) ?></span></div></td>
          <td><span style="font-size:18px;font-weight:700;color:<?= $cnt>0?'var(--primary)':'var(--slate-400)' ?>"><?= $cnt ?></span> <small style="color:var(--slate-400)">entri</small></td>
          <td>
            <div class="btn-group">
              <a href="../api/cetak_jurnal.php?guru_id=<?= $g['id'] ?>&tgl_mulai=<?= $tglMulai ?>&tgl_selesai=<?= $tglSelesai ?>&format=pdf" target="_blank" class="btn btn-sm" style="background:var(--red-light);color:var(--red)"><i class="fas fa-file-pdf"></i> PDF</a>
              <a href="../api/cetak_jurnal.php?guru_id=<?= $g['id'] ?>&tgl_mulai=<?= $tglMulai ?>&tgl_selesai=<?= $tglSelesai ?>&format=excel" class="btn btn-sm" style="background:var(--primary-light);color:var(--primary)"><i class="fas fa-file-excel"></i> Excel</a>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
