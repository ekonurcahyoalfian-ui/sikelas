<?php
session_start();
require_once __DIR__ . '/../includes/config.php';
requireAdmin();
$pageTitle = 'Rekap Nilai';
$activePage = 'rekap_nilai';
$db = getDB();

$filterKelas = $_GET['kelas'] ?? '';
$filterMapel = $_GET['mapel'] ?? '';
$kelasList   = $db->query('SELECT * FROM kelas ORDER BY nama')->fetchAll();
$mapelList   = $db->query('SELECT * FROM mapel ORDER BY nama')->fetchAll();

$sqlSiswa = 'SELECT s.*,k.nama as kelas_nama FROM siswa s LEFT JOIN kelas k ON k.id=s.kelas_id WHERE 1=1';
$params = [];
if ($filterKelas) { $sqlSiswa .= ' AND s.kelas_id=?'; $params[] = $filterKelas; }
$sqlSiswa .= ' ORDER BY k.nama,s.nama';
$stmt = $db->prepare($sqlSiswa); $stmt->execute($params);
$siswaList = $stmt->fetchAll();

$targetMapels = $filterMapel ? array_filter($mapelList, fn($m) => $m['id']==$filterMapel) : $mapelList;

function getNilai($db, $siswaId, $mapelId) {
    $n = $db->prepare('SELECT n.*,GROUP_CONCAT(nh.nilai ORDER BY nh.urutan) as harian_str FROM nilai n LEFT JOIN nilai_harian nh ON nh.nilai_id=n.id WHERE n.siswa_id=? AND n.mapel_id=? GROUP BY n.id');
    $n->execute([$siswaId,$mapelId]);
    return $n->fetch();
}

include __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
  <div class="page-header-left"><h1>Rekap Nilai</h1><p>Lihat dan download rekap nilai siswa</p></div>
  <div class="page-header-right">
    <a href="../api/cetak_nilai.php?kelas=<?= $filterKelas ?>&mapel=<?= $filterMapel ?>&format=excel" class="btn btn-primary"><i class="fas fa-file-excel"></i> Download Excel</a>
  </div>
</div>

<form method="GET" class="filter-bar" style="margin-bottom:16px">
  <div class="form-group"><label class="form-label">Kelas</label>
    <select name="kelas" class="form-control">
      <option value="">Semua</option>
      <?php foreach ($kelasList as $k): ?><option value="<?= $k['id'] ?>" <?= $filterKelas==$k['id']?'selected':'' ?>>Kelas <?= e($k['nama']) ?></option><?php endforeach; ?>
    </select></div>
  <div class="form-group"><label class="form-label">Mapel</label>
    <select name="mapel" class="form-control">
      <option value="">Semua</option>
      <?php foreach ($mapelList as $m): ?><option value="<?= $m['id'] ?>" <?= $filterMapel==$m['id']?'selected':'' ?>><?= e($m['nama']) ?></option><?php endforeach; ?>
    </select></div>
  <div class="form-group" style="align-self:flex-end"><button type="submit" class="btn btn-outline"><i class="fas fa-filter"></i> Filter</button></div>
</form>

<div class="card">
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th rowspan="2" style="vertical-align:middle">Siswa</th>
          <th rowspan="2" style="vertical-align:middle">Kelas</th>
          <?php foreach ($targetMapels as $m): ?>
          <th colspan="4" style="text-align:center;border-left:2px solid var(--slate-200)"><?= e($m['nama']) ?></th>
          <?php endforeach; ?>
        </tr>
        <tr>
          <?php foreach ($targetMapels as $m): ?>
          <th style="font-size:11px;border-left:2px solid var(--slate-200)">Harian</th>
          <th style="font-size:11px">ASTS</th>
          <th style="font-size:11px">ASAS</th>
          <th style="font-size:11px;color:var(--primary)">Akhir</th>
          <?php endforeach; ?>
        </tr>
      </thead>
      <tbody>
      <?php foreach ($siswaList as $s): ?>
        <tr>
          <td><strong><?= e($s['nama']) ?></strong></td>
          <td><?= e($s['kelas_nama']??'-') ?></td>
          <?php foreach ($targetMapels as $m):
            $n = getNilai($db,$s['id'],$m['id']);
            $harianArr = $n ? array_map('floatval', explode(',', $n['harian_str']??'')) : [];
            $rataH = count($harianArr) ? array_sum($harianArr)/count($harianArr) : 0;
            $asts  = $n ? (float)$n['nilai_asts'] : 0;
            $asas  = $n ? (float)$n['nilai_asas'] : 0;
            $akhir = $n ? ($rataH+$asts+$asas)/3 : 0;
            $ac = $akhir>=75?'var(--primary)':($akhir>0?'var(--red)':'var(--slate-400)');
          ?>
          <td style="border-left:2px solid var(--slate-100);text-align:center"><?= $n&&count($harianArr)?number_format($rataH,1):'-' ?></td>
          <td style="text-align:center"><?= $n&&$n['nilai_asts']?number_format($asts,1):'-' ?></td>
          <td style="text-align:center"><?= $n&&$n['nilai_asas']?number_format($asas,1):'-' ?></td>
          <td style="text-align:center;font-weight:700;color:<?= $ac ?>"><?= $n?number_format($akhir,1):'-' ?></td>
          <?php endforeach; ?>
        </tr>
      <?php endforeach; ?>
      <?php if (!$siswaList): ?><tr><td colspan="100" style="text-align:center;padding:32px;color:var(--slate-400)">Tidak ada data.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
