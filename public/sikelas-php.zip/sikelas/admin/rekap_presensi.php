<?php
session_start();
require_once __DIR__ . '/../includes/config.php';
requireAdmin();
$pageTitle = 'Rekap Presensi';
$activePage = 'rekap_presensi';
$db = getDB();

$filterKelas = $_GET['kelas'] ?? '';
$filterGuru  = $_GET['guru'] ?? '';
$filterMapel = $_GET['mapel'] ?? '';
$tglMulai    = $_GET['tgl_mulai'] ?? date('Y-m-01');
$tglSelesai  = $_GET['tgl_selesai'] ?? date('Y-m-d');

$sql = 'SELECT j.*,k.nama as kelas_nama,m.nama as mapel_nama,u.nama as guru_nama FROM jadwal_pelajaran j JOIN kelas k ON k.id=j.kelas_id JOIN mapel m ON m.id=j.mapel_id JOIN users u ON u.id=j.guru_id WHERE 1=1';
$params = [];
if ($filterKelas) { $sql .= ' AND j.kelas_id=?'; $params[] = $filterKelas; }
if ($filterGuru)  { $sql .= ' AND j.guru_id=?';  $params[] = $filterGuru; }
if ($filterMapel) { $sql .= ' AND j.mapel_id=?'; $params[] = $filterMapel; }
$sql .= ' ORDER BY k.nama,m.nama';
$stmt = $db->prepare($sql); $stmt->execute($params);
$jadwalList = $stmt->fetchAll();

$kelasList = $db->query('SELECT * FROM kelas ORDER BY nama')->fetchAll();
$guruList  = $db->query("SELECT id,nama FROM users WHERE role='guru' ORDER BY nama")->fetchAll();
$mapelList = $db->query('SELECT * FROM mapel ORDER BY nama')->fetchAll();
$config    = getKonfigurasi();
include __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
  <div class="page-header-left"><h1>Rekap Presensi</h1><p>Download rekap presensi berdasarkan filter</p></div>
</div>

<div class="card" style="margin-bottom:20px">
  <div class="card-header"><span class="card-title">Filter</span></div>
  <div class="card-body">
    <form method="GET" class="filter-bar">
      <div class="form-group"><label class="form-label">Kelas</label>
        <select name="kelas" class="form-control">
          <option value="">Semua</option>
          <?php foreach ($kelasList as $k): ?><option value="<?= $k['id'] ?>" <?= $filterKelas==$k['id']?'selected':'' ?>>Kelas <?= e($k['nama']) ?></option><?php endforeach; ?>
        </select></div>
      <div class="form-group"><label class="form-label">Guru</label>
        <select name="guru" class="form-control">
          <option value="">Semua</option>
          <?php foreach ($guruList as $g): ?><option value="<?= $g['id'] ?>" <?= $filterGuru==$g['id']?'selected':'' ?>><?= e($g['nama']) ?></option><?php endforeach; ?>
        </select></div>
      <div class="form-group"><label class="form-label">Mapel</label>
        <select name="mapel" class="form-control">
          <option value="">Semua</option>
          <?php foreach ($mapelList as $m): ?><option value="<?= $m['id'] ?>" <?= $filterMapel==$m['id']?'selected':'' ?>><?= e($m['nama']) ?></option><?php endforeach; ?>
        </select></div>
      <div class="form-group"><label class="form-label">Dari</label>
        <input type="date" name="tgl_mulai" class="form-control" value="<?= $tglMulai ?>"></div>
      <div class="form-group"><label class="form-label">Sampai</label>
        <input type="date" name="tgl_selesai" class="form-control" value="<?= $tglSelesai ?>"></div>
      <div class="form-group" style="align-self:flex-end">
        <button type="submit" class="btn btn-outline"><i class="fas fa-filter"></i> Filter</button>
      </div>
    </form>
  </div>
</div>

<div class="card">
  <div class="table-wrap">
    <table>
      <thead><tr><th>Kelas</th><th>Mata Pelajaran</th><th>Guru</th><th>Hari &amp; Jam</th><th>Download</th></tr></thead>
      <tbody>
      <?php foreach ($jadwalList as $j): ?>
        <tr>
          <td><?= e($j['kelas_nama']) ?></td>
          <td><?= e($j['mapel_nama']) ?></td>
          <td><?= e($j['guru_nama']) ?></td>
          <td><?= e($j['hari']) ?> <?= substr($j['jam_mulai'],0,5) ?>&ndash;<?= substr($j['jam_selesai'],0,5) ?></td>
          <td>
            <div class="btn-group">
              <a href="../api/cetak_presensi.php?jadwal_id=<?= $j['id'] ?>&tgl_mulai=<?= $tglMulai ?>&tgl_selesai=<?= $tglSelesai ?>&format=pdf" target="_blank" class="btn btn-sm" style="background:var(--red-light);color:var(--red)"><i class="fas fa-file-pdf"></i> PDF</a>
              <a href="../api/cetak_presensi.php?jadwal_id=<?= $j['id'] ?>&tgl_mulai=<?= $tglMulai ?>&tgl_selesai=<?= $tglSelesai ?>&format=excel" class="btn btn-sm" style="background:var(--primary-light);color:var(--primary)"><i class="fas fa-file-excel"></i> Excel</a>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$jadwalList): ?><tr><td colspan="5" style="text-align:center;padding:32px;color:var(--slate-400)">Tidak ada jadwal sesuai filter.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
