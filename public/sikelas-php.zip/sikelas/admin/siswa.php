<?php
session_start();
require_once __DIR__ . '/../includes/config.php';
requireAdmin();
$pageTitle = 'Data Siswa';
$activePage = 'siswa';
$db = getDB();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $act = $_POST['act'] ?? '';
    if ($act === 'save') {
        $nama  = trim($_POST['nama'] ?? '');
        $nisn  = trim($_POST['nisn'] ?? '');
        $alamat= trim($_POST['alamat'] ?? '');
        $ayah  = trim($_POST['nama_ayah'] ?? '');
        $ibu   = trim($_POST['nama_ibu'] ?? '');
        $kelas = $_POST['kelas_id'] ?: null;
        $id    = (int)($_POST['id'] ?? 0);
        if ($nama && $nisn) {
            if ($id) $db->prepare('UPDATE siswa SET nama=?,nisn=?,alamat=?,nama_ayah=?,nama_ibu=?,kelas_id=? WHERE id=?')->execute([$nama,$nisn,$alamat,$ayah,$ibu,$kelas,$id]);
            else $db->prepare('INSERT INTO siswa(nama,nisn,alamat,nama_ayah,nama_ibu,kelas_id,poin) VALUES(?,?,?,?,?,?,100)')->execute([$nama,$nisn,$alamat,$ayah,$ibu,$kelas]);
            flash('ok','Data siswa berhasil disimpan.');
        }
    } elseif ($act === 'del') {
        $db->prepare('DELETE FROM siswa WHERE id=?')->execute([(int)$_POST['id']]);
        flash('ok','Siswa berhasil dihapus.');
    } elseif ($act === 'naik') {
        $sid = (int)$_POST['siswa_id'];
        $siswa = $db->query('SELECT * FROM siswa WHERE id='.$sid)->fetch();
        $kelasList2 = $db->query('SELECT * FROM kelas ORDER BY nama')->fetchAll();
        $ids = array_column($kelasList2,'id');
        $idx = array_search($siswa['kelas_id'],$ids);
        if ($idx !== false && $idx < count($ids)-1) {
            $db->prepare('UPDATE siswa SET kelas_id=? WHERE id=?')->execute([$ids[$idx+1],$sid]);
            flash('ok','Siswa berhasil dinaikkan kelas.');
        }
    } elseif ($act === 'pindah') {
        $db->prepare('UPDATE siswa SET kelas_id=? WHERE id=?')->execute([(int)$_POST['kelas_tujuan'],(int)$_POST['siswa_id']]);
        flash('ok','Siswa berhasil dipindahkan.');
    } elseif ($act === 'import') {
        if (isset($_FILES['file']) && $_FILES['file']['error']===0) {
            $rows = array_map('str_getcsv', file($_FILES['file']['tmp_name']));
            array_shift($rows);
            $cnt = 0;
            foreach ($rows as $row) {
                $nama = trim($row[0]??''); $nisn = trim($row[1]??'');
                if (!$nama || !$nisn) continue;
                $alamat=$row[2]??''; $ayah=$row[3]??''; $ibu=$row[4]??'';
                $kelasNama=trim($row[5]??'');
                $kelasRow = $kelasNama ? $db->query("SELECT id FROM kelas WHERE nama='".$db->quote($kelasNama)."' LIMIT 1")->fetch() : null;
                $kelasId = $kelasRow['id'] ?? null;
                try { $db->prepare('INSERT IGNORE INTO siswa(nama,nisn,alamat,nama_ayah,nama_ibu,kelas_id,poin) VALUES(?,?,?,?,?,?,100)')->execute([$nama,$nisn,$alamat,$ayah,$ibu,$kelasId]); $cnt++; } catch(Exception $e){}
            }
            flash('ok',"Berhasil import $cnt siswa.");
        }
    }
    header('Location: siswa.php'.($_GET?'?'.http_build_query($_GET):'')); exit;
}

$filterKelas = $_GET['kelas'] ?? '';
$search = $_GET['q'] ?? '';
$sql = 'SELECT s.*, k.nama as kelas_nama FROM siswa s LEFT JOIN kelas k ON k.id=s.kelas_id WHERE 1=1';
$params = [];
if ($filterKelas) { $sql .= ' AND s.kelas_id=?'; $params[] = $filterKelas; }
if ($search) { $sql .= ' AND (s.nama LIKE ? OR s.nisn LIKE ?)'; $params[] = "%$search%"; $params[] = "%$search%"; }
$sql .= ' ORDER BY k.nama, s.nama';
$stmt = $db->prepare($sql); $stmt->execute($params);
$siswaList = $stmt->fetchAll();
$kelasList = $db->query('SELECT * FROM kelas ORDER BY nama')->fetchAll();
$editData  = isset($_GET['edit']) ? $db->query('SELECT * FROM siswa WHERE id='.(int)$_GET['edit'])->fetch() : null;
$pindahData= isset($_GET['pindah']) ? $db->query('SELECT * FROM siswa WHERE id='.(int)$_GET['pindah'])->fetch() : null;
include __DIR__ . '/../includes/header.php';
$ok = flash('ok');
?>
<?php if ($ok): ?><div class="alert alert-success alert-auto"><i class="fas fa-check-circle"></i> <?= e($ok) ?></div><?php endif; ?>

<div class="page-header">
  <div class="page-header-left"><h1>Data Siswa</h1><p><?= count($siswaList) ?> siswa ditemukan</p></div>
  <div class="page-header-right">
    <a href="../api/template_siswa.php" class="btn btn-outline"><i class="fas fa-download"></i> Template CSV</a>
    <button class="btn btn-outline" onclick="openModal('modalImport')"><i class="fas fa-upload"></i> Import CSV</button>
    <button class="btn btn-primary" onclick="openModal('modalSiswa')"><i class="fas fa-plus"></i> Tambah Siswa</button>
  </div>
</div>

<!-- Filter -->
<form method="GET" class="filter-bar" style="margin-bottom:16px">
  <div class="form-group">
    <label class="form-label">Cari</label>
    <input type="text" name="q" class="form-control" placeholder="Nama / NISN..." value="<?= e($search) ?>" style="width:200px">
  </div>
  <div class="form-group">
    <label class="form-label">Kelas</label>
    <select name="kelas" class="form-control">
      <option value="">Semua Kelas</option>
      <?php foreach ($kelasList as $k): ?>
      <option value="<?= $k['id'] ?>" <?= $filterKelas==$k['id']?'selected':'' ?>>Kelas <?= e($k['nama']) ?></option>
      <?php endforeach; ?>
    </select>
  </div>
  <div class="form-group" style="align-self:flex-end">
    <button type="submit" class="btn btn-outline"><i class="fas fa-search"></i> Cari</button>
    <a href="siswa.php" class="btn btn-outline">Reset</a>
  </div>
</form>

<div class="card">
  <div class="table-wrap">
    <table>
      <thead><tr><th>No</th><th>Nama Siswa</th><th>NISN</th><th>Kelas</th><th>Poin</th><th>Aksi</th></tr></thead>
      <tbody>
      <?php foreach ($siswaList as $i => $s):
        $poinColor = $s['poin']>=80?'badge-emerald':($s['poin']>=60?'badge-amber':'badge-red');
      ?>
        <tr>
          <td><?= $i+1 ?></td>
          <td>
            <div class="user-cell">
              <div class="avatar avatar-violet"><?= strtoupper(substr($s['nama'],0,1)) ?></div>
              <div><div class="user-cell-name"><?= e($s['nama']) ?></div><div class="user-cell-sub"><?= e($s['alamat'] ? substr($s['alamat'],0,30).'...' : '') ?></div></div>
            </div>
          </td>
          <td><code><?= e($s['nisn']) ?></code></td>
          <td><?= $s['kelas_nama'] ? '<span class="badge badge-blue">'.e($s['kelas_nama']).'</span>' : '-' ?></td>
          <td><span class="badge <?= $poinColor ?>"><?= $s['poin'] ?></span></td>
          <td>
            <div class="btn-group">
              <a href="siswa.php?edit=<?= $s['id'] ?>" class="btn-icon edit" title="Edit"><i class="fas fa-edit"></i></a>
              <form method="POST" style="display:inline" onsubmit="return confirm('Naikan kelas siswa ini?')">
                <input type="hidden" name="act" value="naik"><input type="hidden" name="siswa_id" value="<?= $s['id'] ?>">
                <button class="btn-icon" title="Naik Kelas" style="color:var(--primary)"><i class="fas fa-arrow-up"></i></button>
              </form>
              <a href="siswa.php?pindah=<?= $s['id'] ?>" class="btn-icon" title="Pindah Kelas" style="color:var(--amber)"><i class="fas fa-arrow-right"></i></a>
              <form method="POST" style="display:inline" onsubmit="return confirm('Hapus siswa ini?')">
                <input type="hidden" name="act" value="del"><input type="hidden" name="id" value="<?= $s['id'] ?>">
                <button class="btn-icon del"><i class="fas fa-trash"></i></button>
              </form>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$siswaList): ?><tr><td colspan="6" style="text-align:center;padding:32px;color:var(--slate-400)">Tidak ada data siswa.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Modal Tambah/Edit -->
<div class="modal-overlay" id="modalSiswa">
  <div class="modal modal-lg">
    <div class="modal-header"><span class="modal-title"><?= $editData?'Edit':'Tambah' ?> Siswa</span><button class="modal-close" onclick="closeModal('modalSiswa')">&times;</button></div>
    <form method="POST">
      <input type="hidden" name="act" value="save"><input type="hidden" name="id" value="<?= $editData['id']??0 ?>">
      <div class="modal-body">
        <div class="form-group"><label class="form-label">Nama Lengkap <span class="req">*</span></label>
          <input type="text" name="nama" class="form-control" value="<?= e($editData['nama']??'') ?>" required></div>
        <div class="form-row">
          <div class="form-group"><label class="form-label">NISN <span class="req">*</span></label>
            <input type="text" name="nisn" class="form-control" value="<?= e($editData['nisn']??'') ?>" required></div>
          <div class="form-group"><label class="form-label">Kelas</label>
            <select name="kelas_id" class="form-control">
              <option value="">-- Pilih Kelas --</option>
              <?php foreach ($kelasList as $k): ?><option value="<?= $k['id'] ?>" <?= ($editData['kelas_id']??'')==$k['id']?'selected':'' ?>>Kelas <?= e($k['nama']) ?></option><?php endforeach; ?>
            </select></div>
        </div>
        <div class="form-group"><label class="form-label">Alamat</label>
          <textarea name="alamat" class="form-control" rows="2"><?= e($editData['alamat']??'') ?></textarea></div>
        <div class="form-row">
          <div class="form-group"><label class="form-label">Nama Ayah</label>
            <input type="text" name="nama_ayah" class="form-control" value="<?= e($editData['nama_ayah']??'') ?>"></div>
          <div class="form-group"><label class="form-label">Nama Ibu</label>
            <input type="text" name="nama_ibu" class="form-control" value="<?= e($editData['nama_ibu']??'') ?>"></div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline" onclick="closeModal('modalSiswa')">Batal</button>
        <button type="submit" class="btn btn-primary">Simpan</button>
      </div>
    </form>
  </div>
</div>

<!-- Modal Pindah Kelas -->
<div class="modal-overlay" id="modalPindah">
  <div class="modal">
    <div class="modal-header"><span class="modal-title">Pindah Kelas: <?= e($pindahData['nama']??'') ?></span><button class="modal-close" onclick="closeModal('modalPindah')">&times;</button></div>
    <form method="POST">
      <input type="hidden" name="act" value="pindah"><input type="hidden" name="siswa_id" value="<?= $pindahData['id']??0 ?>">
      <div class="modal-body">
        <div class="form-group"><label class="form-label">Kelas Tujuan</label>
          <select name="kelas_tujuan" class="form-control">
            <option value="">-- Pilih Kelas --</option>
            <?php foreach ($kelasList as $k): ?><option value="<?= $k['id'] ?>" <?= ($pindahData['kelas_id']??'')==$k['id']?'selected':'' ?>>Kelas <?= e($k['nama']) ?></option><?php endforeach; ?>
          </select></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline" onclick="closeModal('modalPindah')">Batal</button>
        <button type="submit" class="btn btn-amber">Pindahkan</button>
      </div>
    </form>
  </div>
</div>

<!-- Modal Import -->
<div class="modal-overlay" id="modalImport">
  <div class="modal">
    <div class="modal-header"><span class="modal-title">Import Siswa (CSV)</span><button class="modal-close" onclick="closeModal('modalImport')">&times;</button></div>
    <form method="POST" enctype="multipart/form-data">
      <input type="hidden" name="act" value="import">
      <div class="modal-body">
        <div class="alert alert-info"><i class="fas fa-info-circle"></i> Format: nama, nisn, alamat, nama_ayah, nama_ibu, kelas</div>
        <div class="form-group"><label class="form-label">File CSV</label><input type="file" name="file" class="form-control" accept=".csv" required></div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline" onclick="closeModal('modalImport')">Batal</button>
        <button type="submit" class="btn btn-primary"><i class="fas fa-upload"></i> Import</button>
      </div>
    </form>
  </div>
</div>

<?php if ($editData): ?><script>openModal('modalSiswa');</script><?php endif; ?>
<?php if ($pindahData): ?><script>openModal('modalPindah');</script><?php endif; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
