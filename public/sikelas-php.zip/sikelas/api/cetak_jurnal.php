<?php
session_start();
require_once __DIR__ . '/../includes/config.php';
requireLogin();
$db = getDB();
$guruId    = (int)($_GET['guru_id']??0);
$tglMulai  = $_GET['tgl_mulai'] ?? date('Y-m-01');
$tglSelesai= $_GET['tgl_selesai'] ?? date('Y-m-d');
$format    = $_GET['format'] ?? 'pdf';

$guru = $db->query('SELECT * FROM users WHERE id='.$guruId)->fetch();
$config = getKonfigurasi();
$jurnals = $db->prepare('SELECT jm.*,jp.hari,jp.jam_mulai,jp.jam_selesai,k.nama as kelas_nama,m.nama as mapel_nama FROM jurnal_mengajar jm JOIN jadwal_pelajaran jp ON jp.id=jm.jadwal_id JOIN kelas k ON k.id=jp.kelas_id JOIN mapel m ON m.id=jp.mapel_id WHERE jp.guru_id=? AND jm.tanggal BETWEEN ? AND ? ORDER BY jm.tanggal');
$jurnals->execute([$guruId,$tglMulai,$tglSelesai]);
$jurnals = $jurnals->fetchAll();

if ($format==='excel') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="jurnal_'.($guru['nama']??'guru').'_'.$tglMulai.'_'.$tglSelesai.'.csv"');
    echo "\xEF\xBB\xBF";
    $out = fopen('php://output','w');
    fputcsv($out,['Sekolah',$config['nama_sekolah']]);
    fputcsv($out,['Guru',$guru['nama']??'']);
    fputcsv($out,['Periode',$tglMulai.' s.d. '.$tglSelesai]);
    fputcsv($out,[]);
    fputcsv($out,['Tanggal','Hari','Jam','Kelas','Mata Pelajaran','Materi','Kegiatan Pembelajaran','Status TTD']);
    foreach ($jurnals as $j) {
        fputcsv($out,[$j['tanggal'],$j['hari'],substr($j['jam_mulai'],0,5).'-'.substr($j['jam_selesai'],0,5),$j['kelas_nama'],$j['mapel_nama'],$j['materi'],$j['kegiatan_pembelajaran']??'',$j['ttd_guru']?'Sudah TTD':'Belum TTD']);
    }
    fputcsv($out,[]);
    fputcsv($out,[COPYRIGHT]);
    fclose($out);
} else { ?>
<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><title>Jurnal Mengajar</title>
<style>body{font-family:Arial,sans-serif;font-size:11px;margin:20px}h2,h3{text-align:center;margin:4px 0}table{width:100%;border-collapse:collapse;margin-top:10px}th,td{border:1px solid #333;padding:5px;text-align:left}th{background:#e8f5e9}.footer{text-align:center;font-size:9px;color:#666;margin-top:20px}.sign-row{display:flex;justify-content:space-between;margin-top:30px}.sign-box{text-align:center;width:200px}.sign-line{border-bottom:1px solid #333;margin-top:60px}@media print{.no-print{display:none}}</style>
</head><body>
<div class="no-print" style="margin-bottom:12px"><button onclick="window.print()" style="padding:8px 20px;background:#059669;color:#fff;border:none;border-radius:6px;cursor:pointer">&#128424; Cetak / Simpan PDF</button></div>
<h2><?= e($config['nama_sekolah']) ?></h2>
<p style="text-align:center"><?= e($config['alamat_sekolah']) ?></p><hr>
<h3>JURNAL MENGAJAR</h3>
<p style="text-align:center">Guru: <strong><?= e($guru['nama']??'') ?></strong> | Periode: <?= $tglMulai ?> s.d. <?= $tglSelesai ?></p>
<table>
<thead><tr><th>No</th><th>Tanggal</th><th>Hari</th><th>Jam</th><th>Kelas</th><th>Mata Pelajaran</th><th>Materi</th><th>Kegiatan</th><th>TTD</th></tr></thead>
<tbody>
<?php foreach ($jurnals as $i => $j): ?>
<tr>
  <td><?= $i+1 ?></td><td><?= e($j['tanggal']) ?></td><td><?= e($j['hari']) ?></td>
  <td><?= substr($j['jam_mulai'],0,5) ?>-<?= substr($j['jam_selesai'],0,5) ?></td>
  <td><?= e($j['kelas_nama']) ?></td><td><?= e($j['mapel_nama']) ?></td>
  <td><?= e($j['materi']) ?></td><td><?= e($j['kegiatan_pembelajaran']??'') ?></td>
  <td style="text-align:center"><?= $j['ttd_guru']?'<img src="'.$j['ttd_guru'].'" style="max-height:40px">':'<span style="color:#999">-</span>' ?></td>
</tr>
<?php endforeach; ?>
<?php if (!$jurnals): ?><tr><td colspan="9" style="text-align:center;color:#999">Tidak ada data jurnal.</td></tr><?php endif; ?>
</tbody></table>
<div class="sign-row">
  <div class="sign-box">Guru Mata Pelajaran,<div class="sign-line"></div><?= e($guru['nama']??'') ?></div>
  <div class="sign-box">Kepala Sekolah,<div class="sign-line"></div><?= e($config['nama_kepsek']) ?></div>
</div>
<div class="footer"><?= COPYRIGHT ?></div>
</body></html>
<?php } ?>
