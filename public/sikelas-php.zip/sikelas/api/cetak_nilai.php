<?php
session_start();
require_once __DIR__ . '/../includes/config.php';
requireLogin();
$db = getDB();
$filterKelas = (int)($_GET['kelas']??0);
$filterMapel = (int)($_GET['mapel']??0);
$config = getKonfigurasi();

$sqlSiswa = 'SELECT s.*,k.nama as kelas_nama FROM siswa s LEFT JOIN kelas k ON k.id=s.kelas_id WHERE 1=1';
$params=[];
if ($filterKelas){$sqlSiswa.=' AND s.kelas_id=?';$params[]=$filterKelas;}
$sqlSiswa.=' ORDER BY k.nama,s.nama';
$stmt=$db->prepare($sqlSiswa);$stmt->execute($params);
$siswas=$stmt->fetchAll();
$mapels=$filterMapel?$db->query('SELECT * FROM mapel WHERE id='.$filterMapel)->fetchAll():$db->query('SELECT * FROM mapel ORDER BY nama')->fetchAll();

header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="rekap_nilai_'.$config['tahun_ajaran'].'.csv"');
echo "\xEF\xBB\xBF";
$out=fopen('php://output','w');
fputcsv($out,['Sekolah',$config['nama_sekolah'],'Tahun Ajaran',$config['tahun_ajaran'],'Semester',$config['semester']]);
fputcsv($out,[]);
$h=['Nama','NISN','Kelas'];
foreach($mapels as $m){$h[]=$m['nama'].' (Harian)';$h[]=$m['nama'].' (ASTS)';$h[]=$m['nama'].' (ASAS)';$h[]=$m['nama'].' (Akhir)';}
fputcsv($out,$h);
foreach($siswas as $s){
    $row=[$s['nama'],$s['nisn'],$s['kelas_nama']??''];
    foreach($mapels as $m){
        $n=$db->query('SELECT n.*,GROUP_CONCAT(nh.nilai ORDER BY nh.urutan) as hs FROM nilai n LEFT JOIN nilai_harian nh ON nh.nilai_id=n.id WHERE n.siswa_id='.$s['id'].' AND n.mapel_id='.$m['id'].' GROUP BY n.id')->fetch();
        $harr=$n&&$n['hs']?array_map('floatval',explode(',',$n['hs'])):[];
        $rH=count($harr)?array_sum($harr)/count($harr):0;
        $akhir=$n?($rH+(float)$n['nilai_asts']+(float)$n['nilai_asas'])/3:0;
        $row[]=count($harr)?number_format($rH,1):'-';
        $row[]=$n&&$n['nilai_asts']?number_format((float)$n['nilai_asts'],1):'-';
        $row[]=$n&&$n['nilai_asas']?number_format((float)$n['nilai_asas'],1):'-';
        $row[]=$n?number_format($akhir,1):'-';
    }
    fputcsv($out,$row);
}
fputcsv($out,[]);fputcsv($out,[COPYRIGHT]);
fclose($out);
