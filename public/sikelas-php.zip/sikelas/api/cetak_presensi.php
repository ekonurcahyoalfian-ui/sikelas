<?php
session_start();
require_once __DIR__ . '/../includes/config.php';
requireLogin();
$db = getDB();
$jadwalId  = (int)($_GET['jadwal_id']??0);
$tglMulai  = $_GET['tgl_mulai'] ?? date('Y-m-d');
$tglSelesai= $_GET['tgl_selesai'] ?? date('Y-m-d');
$format    = $_GET['format'] ?? 'pdf';

$jadwal = $db->query('SELECT j.*,k.nama as kelas_nama,m.nama as mapel_nama,m.kode as mapel_kode,u.nama as guru_nama FROM jadwal_pelajaran j JOIN kelas k ON k.id=j.kelas_id JOIN mapel m ON m.id=j.mapel_id JOIN users u ON u.id=j.guru_id WHERE j.id='.$jadwalId)->fetch();
if (!$jadwal) die('Jadwal tidak ditemukan.');

$siswas = $db->query('SELECT * FROM siswa WHERE kelas_id='.$jadwal['kelas_id'].' ORDER BY nama')->fetchAll();
$config = getKonfigurasi();

// Generate dates
$dates = [];
$d = new DateTime($tglMulai);
$end = new DateTime($tglSelesai);
while ($d <= $end) { $dates[] = $d->format('Y-m-d'); $d->modify('+1 day'); }

if ($format === 'excel') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="presensi_'.$jadwal['mapel_kode'].'_'.$jadwal['kelas_nama'].'_'.$tglMulai.'_'.$tglSelesai.'.csv"');
    echo "\xEF\xBB\xBF";
    $out = fopen('php://output','w');
    // Info
    fputcsv($out, ['Sekolah',$config['nama_sekolah']]);
    fputcsv($out, ['Mata Pelajaran',$jadwal['mapel_nama']]);
    fputcsv($out, ['Kelas',$jadwal['kelas_nama']]);
    fputcsv($out, ['Guru',$jadwal['guru_nama']]);
    fputcsv($out, ['Periode',$tglMulai.' s.d. '.$tglSelesai]);
    fputcsv($out, []);
    $header = ['No','Nama Siswa','NISN'];
    foreach ($dates as $d2) $header[] = date('d/m',strtotime($d2));
    $header = array_merge($header,['Hadir','Izin','Sakit','Alpa']);
    fputcsv($out, $header);
    foreach ($siswas as $i => $s) {
        $row = [$i+1,$s['nama'],$s['nisn']];
        $h=$i2=$sk=$a=0;
        foreach ($dates as $d2) {
            $p=$db->query("SELECT status FROM presensi WHERE jadwal_id=$jadwalId AND tanggal='$d2' AND siswa_id=".$s['id'])->fetchColumn();
            $row[]=substr($p?:'',0,1)?:'-';
            if($p==='Hadir')$h++;elseif($p==='Izin')$i2++;elseif($p==='Sakit')$sk++;elseif($p==='Alpa')$a++;
        }
        $row=array_merge($row,[$h,$i2,$sk,$a]);
        fputcsv($out,$row);
    }
    fputcsv($out,[]);
    fputcsv($out,[COPYRIGHT]);
    fclose($out);
} else {
    // PDF via HTML print
    ?>
<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><title>Presensi</title>
<style>
body{font-family:Arial,sans-serif;font-size:11px;margin:20px}
h2,h3{text-align:center;margin:4px 0}
table{width:100%;border-collapse:collapse;margin-top:10px}
th,td{border:1px solid #333;padding:4px 6px;text-align:center}
th{background:#e8f5e9;font-weight:bold}
td:nth-child(2){text-align:left}
.footer{text-align:center;font-size:9px;color:#666;margin-top:20px}
.sign-row{display:flex;justify-content:space-between;margin-top:30px}
.sign-box{text-align:center;width:200px}
.sign-line{border-bottom:1px solid #333;margin-top:60px}
@media print{.no-print{display:none}}
</style></head><body>
<div class="no-print" style="margin-bottom:12px">
  <button onclick="window.print()" style="padding:8px 20px;background:#059669;color:#fff;border:none;border-radius:6px;cursor:pointer">&#128424; Cetak / Simpan PDF</button>
</div>
<h2><?= e($config['nama_sekolah']) ?></h2>
<p style="text-align:center;margin:2px"><?= e($config['alamat_sekolah']) ?></p>
<hr>
<h3>DAFTAR HADIR SISWA</h3>
<p style="text-align:center">Mata Pelajaran: <strong><?= e($jadwal['mapel_nama']) ?></strong> | Kelas: <strong><?= e($jadwal['kelas_nama']) ?></strong> | Guru: <strong><?= e($jadwal['guru_nama']) ?></strong></p>
<p style="text-align:center">Jam: <?= substr($jadwal['jam_mulai'],0,5) ?>-<?= substr($jadwal['jam_selesai'],0,5) ?> | Periode: <?= $tglMulai ?> s.d. <?= $tglSelesai ?></p>
<table>
<thead><tr><th>No</th><th>Nama Siswa</th><th>NISN</th>
<?php foreach ($dates as $d2): ?><th style="min-width:28px"><?= date('d/m',strtotime($d2)) ?></th><?php endforeach; ?>
<th>H</th><th>I</th><th>S</th><th>A</th></tr></thead>
<tbody>
<?php foreach ($siswas as $i => $s):
  $h=$iz=$sk=$a=0; $cols='';
  foreach ($dates as $d2):
    $p=$db->query("SELECT status FROM presensi WHERE jadwal_id=$jadwalId AND tanggal='$d2' AND siswa_id=".$s['id'])->fetchColumn();
    $st=substr($p?:'',0,1)?:'-';
    $cols.='<td>'.$st.'</td>';
    if($p==='Hadir')$h++;elseif($p==='Izin')$iz++;elseif($p==='Sakit')$sk++;elseif($p==='Alpa')$a++;
  endforeach;
?>
<tr><td><?= $i+1 ?></td><td style="text-align:left"><?= e($s['nama']) ?></td><td><?= e($s['nisn']) ?></td><?= $cols ?><td><?= $h ?></td><td><?= $iz ?></td><td><?= $sk ?></td><td><?= $a ?></td></tr>
<?php endforeach; ?>
</tbody></table>
<div class="sign-row">
  <div class="sign-box">Mengetahui,<br>Wali Kelas<div class="sign-line"></div></div>
  <div class="sign-box"><?= e($config['nama_kepsek']) ?><br>Kepala Sekolah<div class="sign-line"></div><?= e($config['nama_kepsek']) ?></div>
</div>
<div class="footer"><?= COPYRIGHT ?></div>
</body></html>
<?php } ?>
