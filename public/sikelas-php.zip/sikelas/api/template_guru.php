<?php
require_once __DIR__ . '/../includes/config.php';
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="template_guru.csv"');
echo "\xEF\xBB\xBF";
$out = fopen('php://output','w');
fputcsv($out, ['nama','username','password','is_walas','kelas_wali','mapel']);
fputcsv($out, ['Dra. Siti Fatimah','siti.fatimah','guru123','tidak','','Matematika']);
fputcsv($out, ['Bpk. Ahmad Yusuf','ahmad.yusuf','guru123','ya','VII A','Bahasa Indonesia']);
fclose($out);
