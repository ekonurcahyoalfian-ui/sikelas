<?php
require_once __DIR__ . '/../includes/config.php';
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="template_jadwal.csv"');
echo "\xEF\xBB\xBF";
$out = fopen('php://output','w');
fputcsv($out, ['kelas','mapel','guru','hari','jam_mulai','jam_selesai']);
fputcsv($out, ['VII A','Matematika','Dra. Siti Fatimah','Senin','07:00','07:45']);
fputcsv($out, ['VII A','Bahasa Indonesia','Bpk. Ahmad Yusuf','Senin','07:45','08:30']);
fclose($out);
