<?php
require_once __DIR__ . '/../includes/config.php';
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="template_mapel.csv"');
echo "\xEF\xBB\xBF";
$out = fopen('php://output','w');
fputcsv($out, ['nama','kode','jp_per_pekan']);
fputcsv($out, ['Matematika','MTK',4]);
fputcsv($out, ['Bahasa Indonesia','BIND',4]);
fputcsv($out, ['IPA','IPA',3]);
fputcsv($out, ['IPS','IPS',2]);
fputcsv($out, ['Bahasa Inggris','BING',3]);
fclose($out);
