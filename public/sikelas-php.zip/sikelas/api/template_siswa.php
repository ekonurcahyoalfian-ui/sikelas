<?php
require_once __DIR__ . '/../includes/config.php';
header('Content-Type: text/csv; charset=utf-8');
header('Content-Disposition: attachment; filename="template_siswa.csv"');
echo "\xEF\xBB\xBF"; // BOM UTF-8
$out = fopen('php://output','w');
fputcsv($out, ['nama','nisn','alamat','nama_ayah','nama_ibu','kelas']);
fputcsv($out, ['Budi Santoso','1234567890','Jl. Merdeka No. 1','Santoso','Sri Wahyuni','VII A']);
fputcsv($out, ['Ani Rahayu','0987654321','Jl. Pahlawan No. 5','Rahayu','Siti Aminah','VII A']);
fclose($out);
