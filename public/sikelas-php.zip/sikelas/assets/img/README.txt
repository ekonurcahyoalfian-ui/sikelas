Letakkan file logo.png di folder ini.
Download logo dari: https://i.imgur.com/omtDTAj.png
Simpan sebagai: logo.png
