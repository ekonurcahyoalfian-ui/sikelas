// ============================================================
//  SiKelas - Main JavaScript
//  Copyright © 2026 RUMAHIMI — Sistem Manajemen Kelas
// ============================================================

// Sidebar toggle
function toggleSidebar() {
  document.getElementById('sidebar').classList.toggle('open');
  document.getElementById('sidebarOverlay').classList.toggle('open');
}
function closeSidebar() {
  document.getElementById('sidebar').classList.remove('open');
  document.getElementById('sidebarOverlay').classList.remove('open');
}

// Modal
function openModal(id) { document.getElementById(id).classList.add('open'); }
function closeModal(id) { document.getElementById(id).classList.remove('open'); }
document.addEventListener('click', function(e) {
  if (e.target.classList.contains('modal-overlay')) {
    e.target.classList.remove('open');
  }
});

// Tabs
function switchTab(tabId, groupId) {
  const group = document.getElementById(groupId || 'tabGroup');
  group.querySelectorAll('.tab-btn').forEach(b => b.classList.remove('active'));
  group.querySelectorAll('.tab-pane').forEach(p => p.classList.remove('active'));
  document.querySelector(`[data-tab="${tabId}"]`).classList.add('active');
  document.getElementById(tabId).classList.add('active');
}

// Presensi status toggle
function setStatus(siswaId, status) {
  document.querySelectorAll(`.status-btn[data-siswa="${siswaId}"]`).forEach(b => b.classList.remove('active'));
  const btn = document.querySelector(`.status-btn[data-siswa="${siswaId}"][data-status="${status}"]`);
  if (btn) btn.classList.add('active');
  const input = document.getElementById(`status_${siswaId}`);
  if (input) input.value = status;
}

// Chip toggle (mapel selection)
function toggleChip(el, inputId) {
  el.classList.toggle('selected');
  updateChipInput(inputId);
}
function updateChipInput(inputId) {
  const container = document.getElementById(inputId + '_chips');
  if (!container) return;
  const selected = [...container.querySelectorAll('.chip.selected')].map(c => c.dataset.value);
  document.getElementById(inputId).value = selected.join(',');
}

// Signature Pad
function initSignaturePad(canvasId, hiddenId) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  let drawing = false;

  function getPos(e) {
    const rect = canvas.getBoundingClientRect();
    const scaleX = canvas.width / rect.width;
    const scaleY = canvas.height / rect.height;
    const src = e.touches ? e.touches[0] : e;
    return { x: (src.clientX - rect.left) * scaleX, y: (src.clientY - rect.top) * scaleY };
  }

  function start(e) { drawing = true; const p = getPos(e); ctx.beginPath(); ctx.moveTo(p.x, p.y); e.preventDefault(); }
  function move(e) {
    if (!drawing) return;
    const p = getPos(e);
    ctx.lineTo(p.x, p.y);
    ctx.strokeStyle = '#1e293b'; ctx.lineWidth = 2; ctx.lineCap = 'round'; ctx.stroke();
    e.preventDefault();
  }
  function stop() {
    drawing = false;
    const hidden = document.getElementById(hiddenId);
    if (hidden) hidden.value = canvas.toDataURL('image/png');
  }

  canvas.addEventListener('mousedown', start); canvas.addEventListener('mousemove', move);
  canvas.addEventListener('mouseup', stop); canvas.addEventListener('mouseleave', stop);
  canvas.addEventListener('touchstart', start, {passive:false}); canvas.addEventListener('touchmove', move, {passive:false});
  canvas.addEventListener('touchend', stop);
}

function clearSignature(canvasId, hiddenId) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return;
  canvas.getContext('2d').clearRect(0, 0, canvas.width, canvas.height);
  const hidden = document.getElementById(hiddenId);
  if (hidden) hidden.value = '';
}

// Nilai harian dynamic rows
function addNilaiHarian(siswaId) {
  const container = document.getElementById('harian_' + siswaId);
  const count = container.querySelectorAll('input').length + 1;
  const div = document.createElement('div');
  div.className = 'nilai-harian-item';
  div.style.cssText = 'display:inline-flex;align-items:center;gap:4px;margin:2px';
  div.innerHTML = `<input type="number" name="harian[${siswaId}][]" min="0" max="100" value="0"
    class="form-control" style="width:60px;padding:4px 8px;font-size:12px"
    onchange="updateRataHarian('${siswaId}')">
    <button type="button" onclick="removeNilaiHarian(this,'${siswaId}')"
      style="background:none;border:none;color:#dc2626;cursor:pointer;font-size:13px">&times;</button>`;
  container.appendChild(div);
  updateRataHarian(siswaId);
}

function removeNilaiHarian(btn, siswaId) {
  btn.parentElement.remove();
  updateRataHarian(siswaId);
}

function updateRataHarian(siswaId) {
  const inputs = document.querySelectorAll(`#harian_${siswaId} input`);
  const vals = [...inputs].map(i => parseFloat(i.value) || 0);
  const rata = vals.length ? (vals.reduce((a,b)=>a+b,0)/vals.length).toFixed(1) : '-';
  const el = document.getElementById('rata_' + siswaId);
  if (el) el.textContent = rata;
  updateNilaiAkhir(siswaId);
}

function updateNilaiAkhir(siswaId) {
  const inputs = document.querySelectorAll(`#harian_${siswaId} input`);
  const vals = [...inputs].map(i => parseFloat(i.value) || 0);
  const rataH = vals.length ? vals.reduce((a,b)=>a+b,0)/vals.length : 0;
  const asts = parseFloat(document.getElementById('asts_'+siswaId)?.value) || 0;
  const asas = parseFloat(document.getElementById('asas_'+siswaId)?.value) || 0;
  const akhir = ((rataH + asts + asas) / 3).toFixed(1);
  const el = document.getElementById('akhir_' + siswaId);
  if (el) { el.textContent = akhir; el.style.color = parseFloat(akhir) >= 75 ? '#059669' : '#dc2626'; }
}

// Password toggle
function togglePass(inputId, btnId) {
  const input = document.getElementById(inputId);
  const btn = document.getElementById(btnId);
  if (input.type === 'password') {
    input.type = 'text';
    btn.innerHTML = '<i class="fas fa-eye-slash"></i>';
  } else {
    input.type = 'password';
    btn.innerHTML = '<i class="fas fa-eye"></i>';
  }
}

// Confirm password validation
function checkConfirmPass() {
  const np = document.getElementById('password_baru')?.value;
  const cp = document.getElementById('konfirmasi')?.value;
  const msg = document.getElementById('pass_match_msg');
  if (!msg || !cp) return;
  if (np === cp) { msg.textContent = '✓ Password cocok'; msg.style.color = '#059669'; }
  else { msg.textContent = '✗ Password tidak cocok'; msg.style.color = '#dc2626'; }
}

// Auto-dismiss alerts
document.addEventListener('DOMContentLoaded', function() {
  setTimeout(function() {
    document.querySelectorAll('.alert-auto').forEach(el => {
      el.style.transition = 'opacity .5s';
      el.style.opacity = '0';
      setTimeout(() => el.remove(), 500);
    });
  }, 3500);
});

// Print
function printPage() { window.print(); }
