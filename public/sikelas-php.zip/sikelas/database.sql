-- ============================================================
--  SiKelas - Sistem Manajemen Kelas
--  Database: sikelas
--  Copyright © 2026 RUMAHIMI — Sistem Manajemen Kelas
-- ============================================================

CREATE DATABASE IF NOT EXISTS `sikelas` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE `sikelas`;

-- ----------------------------
-- Tabel: users
-- ----------------------------
CREATE TABLE IF NOT EXISTS `users` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `nama` VARCHAR(150) NOT NULL,
  `username` VARCHAR(80) NOT NULL UNIQUE,
  `password` VARCHAR(255) NOT NULL,
  `role` ENUM('admin','guru') NOT NULL DEFAULT 'guru',
  `is_walas` TINYINT(1) DEFAULT 0,
  `kelas_wali_id` INT DEFAULT NULL,
  `ttd` LONGTEXT DEFAULT NULL COMMENT 'base64 tanda tangan',
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ----------------------------
-- Tabel: kelas
-- ----------------------------
CREATE TABLE IF NOT EXISTS `kelas` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `nama` VARCHAR(50) NOT NULL,
  `tahun_ajaran` VARCHAR(20) NOT NULL DEFAULT '2025/2026',
  `wali_kelas_id` INT DEFAULT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ----------------------------
-- Tabel: mapel
-- ----------------------------
CREATE TABLE IF NOT EXISTS `mapel` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `nama` VARCHAR(100) NOT NULL,
  `kode` VARCHAR(20) NOT NULL,
  `jp_per_pekan` INT DEFAULT 2,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

-- ----------------------------
-- Tabel: mapel_kelas (mapel per kelas)
-- ----------------------------
CREATE TABLE IF NOT EXISTS `mapel_kelas` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `kelas_id` INT NOT NULL,
  `mapel_id` INT NOT NULL,
  `guru_id` INT NOT NULL,
  UNIQUE KEY `uq_kelas_mapel` (`kelas_id`,`mapel_id`),
  FOREIGN KEY (`kelas_id`) REFERENCES `kelas`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`mapel_id`) REFERENCES `mapel`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`guru_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ----------------------------
-- Tabel: siswa
-- ----------------------------
CREATE TABLE IF NOT EXISTS `siswa` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `nama` VARCHAR(150) NOT NULL,
  `nisn` VARCHAR(20) NOT NULL UNIQUE,
  `alamat` TEXT DEFAULT NULL,
  `nama_ayah` VARCHAR(100) DEFAULT NULL,
  `nama_ibu` VARCHAR(100) DEFAULT NULL,
  `kelas_id` INT DEFAULT NULL,
  `poin` INT DEFAULT 100,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`kelas_id`) REFERENCES `kelas`(`id`) ON DELETE SET NULL
) ENGINE=InnoDB;

-- ----------------------------
-- Tabel: jadwal_pelajaran
-- ----------------------------
CREATE TABLE IF NOT EXISTS `jadwal_pelajaran` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `kelas_id` INT NOT NULL,
  `mapel_id` INT NOT NULL,
  `guru_id` INT NOT NULL,
  `hari` ENUM('Senin','Selasa','Rabu','Kamis','Jumat','Sabtu') NOT NULL,
  `jam_mulai` TIME NOT NULL,
  `jam_selesai` TIME NOT NULL,
  FOREIGN KEY (`kelas_id`) REFERENCES `kelas`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`mapel_id`) REFERENCES `mapel`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`guru_id`) REFERENCES `users`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ----------------------------
-- Tabel: presensi
-- ----------------------------
CREATE TABLE IF NOT EXISTS `presensi` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `jadwal_id` INT NOT NULL,
  `tanggal` DATE NOT NULL,
  `siswa_id` INT NOT NULL,
  `status` ENUM('Hadir','Izin','Sakit','Alpa') NOT NULL DEFAULT 'Hadir',
  `catatan` TEXT DEFAULT NULL,
  UNIQUE KEY `uq_presensi` (`jadwal_id`,`tanggal`,`siswa_id`),
  FOREIGN KEY (`jadwal_id`) REFERENCES `jadwal_pelajaran`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`siswa_id`) REFERENCES `siswa`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ----------------------------
-- Tabel: jurnal_mengajar
-- ----------------------------
CREATE TABLE IF NOT EXISTS `jurnal_mengajar` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `jadwal_id` INT NOT NULL,
  `tanggal` DATE NOT NULL,
  `materi` TEXT NOT NULL,
  `kegiatan_pembelajaran` TEXT DEFAULT NULL,
  `ttd_guru` LONGTEXT DEFAULT NULL,
  `sudah_diisi` TINYINT(1) DEFAULT 1,
  UNIQUE KEY `uq_jurnal` (`jadwal_id`,`tanggal`),
  FOREIGN KEY (`jadwal_id`) REFERENCES `jadwal_pelajaran`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ----------------------------
-- Tabel: jenis_pelanggaran
-- ----------------------------
CREATE TABLE IF NOT EXISTS `jenis_pelanggaran` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `nama` VARCHAR(200) NOT NULL,
  `kategori` ENUM('Ringan','Sedang','Berat') NOT NULL DEFAULT 'Ringan',
  `poin_pengurangan` INT NOT NULL DEFAULT 5
) ENGINE=InnoDB;

-- ----------------------------
-- Tabel: pelanggaran
-- ----------------------------
CREATE TABLE IF NOT EXISTS `pelanggaran` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `siswa_id` INT NOT NULL,
  `tanggal` DATE NOT NULL,
  `jenis_pelanggaran_id` INT NOT NULL,
  `keterangan` TEXT DEFAULT NULL,
  `poin_pengurangan` INT NOT NULL,
  `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (`siswa_id`) REFERENCES `siswa`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`jenis_pelanggaran_id`) REFERENCES `jenis_pelanggaran`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ----------------------------
-- Tabel: nilai
-- ----------------------------
CREATE TABLE IF NOT EXISTS `nilai` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `siswa_id` INT NOT NULL,
  `mapel_id` INT NOT NULL,
  `kelas_id` INT NOT NULL,
  `semester` VARCHAR(20) DEFAULT 'Ganjil',
  `nilai_asts` DECIMAL(5,2) DEFAULT NULL,
  `nilai_asas` DECIMAL(5,2) DEFAULT NULL,
  UNIQUE KEY `uq_nilai` (`siswa_id`,`mapel_id`,`kelas_id`,`semester`),
  FOREIGN KEY (`siswa_id`) REFERENCES `siswa`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`mapel_id`) REFERENCES `mapel`(`id`) ON DELETE CASCADE,
  FOREIGN KEY (`kelas_id`) REFERENCES `kelas`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ----------------------------
-- Tabel: nilai_harian
-- ----------------------------
CREATE TABLE IF NOT EXISTS `nilai_harian` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `nilai_id` INT NOT NULL,
  `nilai` DECIMAL(5,2) NOT NULL,
  `urutan` INT DEFAULT 1,
  FOREIGN KEY (`nilai_id`) REFERENCES `nilai`(`id`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- ----------------------------
-- Tabel: konfigurasi
-- ----------------------------
CREATE TABLE IF NOT EXISTS `konfigurasi` (
  `id` INT AUTO_INCREMENT PRIMARY KEY,
  `nama_sekolah` VARCHAR(200) DEFAULT 'SMP Negeri 1',
  `alamat_sekolah` TEXT DEFAULT 'Jl. Pendidikan No. 1',
  `nama_kepsek` VARCHAR(150) DEFAULT 'Drs. Ahmad Fauzi, M.Pd',
  `ttd_kepsek` LONGTEXT DEFAULT NULL,
  `tahun_ajaran` VARCHAR(20) DEFAULT '2025/2026',
  `semester` ENUM('Ganjil','Genap') DEFAULT 'Ganjil'
) ENGINE=InnoDB;

-- ============================================================
-- DATA AWAL
-- ============================================================

-- Admin default (password: admin123)
INSERT INTO `users` (`nama`, `username`, `password`, `role`) VALUES
('Administrator', 'admin', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin');
-- password default: password (Laravel hash) — ganti dengan: password_hash('admin123', PASSWORD_BCRYPT)

-- Konfigurasi default
INSERT INTO `konfigurasi` (`nama_sekolah`, `alamat_sekolah`, `nama_kepsek`, `tahun_ajaran`, `semester`) VALUES
('SMP Negeri 1', 'Jl. Pendidikan No. 1', 'Drs. Ahmad Fauzi, M.Pd', '2025/2026', 'Ganjil');

-- Jenis Pelanggaran default
INSERT INTO `jenis_pelanggaran` (`nama`, `kategori`, `poin_pengurangan`) VALUES
('Terlambat masuk sekolah', 'Ringan', 3),
('Tidak membawa buku pelajaran', 'Ringan', 2),
('Tidak mengerjakan PR', 'Ringan', 5),
('Berpakaian tidak rapi', 'Ringan', 3),
('Membolos pelajaran', 'Sedang', 10),
('Berkelahi', 'Berat', 25),
('Merokok di lingkungan sekolah', 'Berat', 30),
('Merusak fasilitas sekolah', 'Sedang', 15),
('Tidak hormat kepada guru', 'Sedang', 10),
('Membawa HP tanpa izin', 'Ringan', 5);
