<?php
session_start();
require_once __DIR__ . '/../includes/config.php';
requireGuru();
$pageTitle = 'Dashboard Guru';
$activePage = 'dashboard';
$db = getDB();
$guruId = $_SESSION['user_id'];

$hariMap = [0=>'Minggu',1=>'Senin',2=>'Selasa',3=>'Rabu',4=>'Kamis',5=>'Jumat',6=>'Sabtu'];
$hariIni = $hariMap[date('N')%7];
$tglIni  = date('Y-m-d');

$jadwalHariIni = $db->prepare('SELECT j.*,k.nama as kelas_nama,m.nama as mapel_nama FROM jadwal_pelajaran j JOIN kelas k ON k.id=j.kelas_id JOIN mapel m ON m.id=j.mapel_id WHERE j.guru_id=? AND j.hari=? ORDER BY j.jam_mulai');
$jadwalHariIni->execute([$guruId,$hariIni]);
$jadwalHariIni = $jadwalHariIni->fetchAll();

$totalJadwal = $db->prepare('SELECT COUNT(*) FROM jadwal_pelajaran WHERE guru_id=?');
$totalJadwal->execute([$guruId]); $totalJadwal = $totalJadwal->fetchColumn();

$totalJurnal = $db->prepare('SELECT COUNT(*) FROM jurnal_mengajar jm JOIN jadwal_pelajaran jp ON jp.id=jm.jadwal_id WHERE jp.guru_id=?');
$totalJurnal->execute([$guruId]); $totalJurnal = $totalJurnal->fetchColumn();

$config = getKonfigurasi();
include __DIR__ . '/../includes/header.php';
?>

<div class="page-header">
  <div class="page-header-left">
    <h1>Halo, <?= e(explode(' ',$_SESSION['nama'])[0]) ?>!</h1>
    <p>Hari ini: <?= $hariIni ?>, <?= formatTanggal($tglIni) ?></p>
  </div>
</div>

<div class="stats-grid">
  <div class="stat-card"><div class="stat-icon bg-blue"><i class="fas fa-calendar-day text-blue"></i></div><div class="stat-value text-blue"><?= count($jadwalHariIni) ?></div><div class="stat-label">Jadwal Hari Ini</div></div>
  <div class="stat-card"><div class="stat-icon bg-emerald"><i class="fas fa-book-open text-emerald"></i></div><div class="stat-value text-emerald"><?= $totalJurnal ?></div><div class="stat-label">Total Jurnal</div></div>
  <div class="stat-card"><div class="stat-icon bg-violet"><i class="fas fa-calendar-alt text-violet"></i></div><div class="stat-value text-violet"><?= $totalJadwal ?></div><div class="stat-label">Total Jadwal/Minggu</div></div>
</div>

<div class="card">
  <div class="card-header"><span class="card-title">Jadwal Mengajar Hari Ini (<?= $hariIni ?>)</span></div>
  <div class="card-body" style="padding:0">
    <?php if ($jadwalHariIni): ?>
    <table>
      <thead><tr><th>Jam</th><th>Mata Pelajaran</th><th>Kelas</th><th>Status</th><th>Aksi</th></tr></thead>
      <tbody>
      <?php foreach ($jadwalHariIni as $j):
        $pStmt = $db->prepare('SELECT COUNT(*) FROM presensi WHERE jadwal_id=? AND tanggal=?');
        $pStmt->execute([$j['id'],$tglIni]); $sudahPresensi = $pStmt->fetchColumn() > 0;
        $jStmt = $db->prepare('SELECT id FROM jurnal_mengajar WHERE jadwal_id=? AND tanggal=?');
        $jStmt->execute([$j['id'],$tglIni]); $sudahJurnal = (bool)$jStmt->fetchColumn();
      ?>
        <tr>
          <td><strong><?= substr($j['jam_mulai'],0,5) ?></strong>&ndash;<?= substr($j['jam_selesai'],0,5) ?></td>
          <td><?= e($j['mapel_nama']) ?></td>
          <td><?= e($j['kelas_nama']) ?></td>
          <td>
            <?php if ($sudahPresensi): ?><span class="badge badge-blue">Presensi ✓</span><?php endif; ?>
            <?php if ($sudahJurnal): ?><span class="badge badge-emerald">Jurnal ✓</span><?php endif; ?>
            <?php if (!$sudahPresensi && !$sudahJurnal): ?><span class="badge badge-slate">Belum diisi</span><?php endif; ?>
          </td>
          <td><a href="presensi.php?jadwal_id=<?= $j['id'] ?>&tanggal=<?= $tglIni ?>" class="btn btn-sm btn-primary"><i class="fas fa-edit"></i> Isi</a></td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
    <?php else: ?>
    <div style="padding:32px;text-align:center;color:var(--slate-400)">Tidak ada jadwal mengajar hari ini.</div>
    <?php endif; ?>
  </div>
</div>
<?php include __DIR__ . '/../includes/footer.php'; ?>
