<?php
session_start();
require_once __DIR__ . '/../includes/config.php';
requireGuru();
$pageTitle = 'Jurnal Mengajar';
$activePage = 'jurnal';
$db = getDB();
$guruId = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD']==='POST' && ($_POST['act']??'')==='edit') {
    $id = (int)$_POST['id'];
    $db->prepare('UPDATE jurnal_mengajar SET materi=?,kegiatan_pembelajaran=?,ttd_guru=? WHERE id=?')
       ->execute([$_POST['materi'],$_POST['kegiatan_pembelajaran'],$_POST['ttd_guru'],$id]);
    flash('ok','Jurnal berhasil diperbarui.');
    header('Location: jurnal.php?'.http_build_query($_GET)); exit;
}

$tglMulai   = $_GET['tgl_mulai'] ?? date('Y-m-01');
$tglSelesai = $_GET['tgl_selesai'] ?? date('Y-m-d');

$jurnals = $db->prepare('SELECT jm.*,jp.hari,jp.jam_mulai,jp.jam_selesai,k.nama as kelas_nama,m.nama as mapel_nama FROM jurnal_mengajar jm JOIN jadwal_pelajaran jp ON jp.id=jm.jadwal_id JOIN kelas k ON k.id=jp.kelas_id JOIN mapel m ON m.id=jp.mapel_id WHERE jp.guru_id=? AND jm.tanggal BETWEEN ? AND ? ORDER BY jm.tanggal DESC');
$jurnals->execute([$guruId,$tglMulai,$tglSelesai]);
$jurnals = $jurnals->fetchAll();
$editJurnal = isset($_GET['edit']) ? $db->query('SELECT * FROM jurnal_mengajar WHERE id='.(int)$_GET['edit'])->fetch() : null;
include __DIR__ . '/../includes/header.php';
$ok = flash('ok');
?>
<?php if ($ok): ?><div class="alert alert-success alert-auto"><i class="fas fa-check-circle"></i> <?= e($ok) ?></div><?php endif; ?>

<div class="page-header">
  <div class="page-header-left"><h1>Jurnal Mengajar</h1><p>Riwayat dan rekap jurnal mengajar Anda</p></div>
  <div class="page-header-right">
    <a href="../api/cetak_jurnal.php?guru_id=<?= $guruId ?>&tgl_mulai=<?= $tglMulai ?>&tgl_selesai=<?= $tglSelesai ?>&format=pdf" target="_blank" class="btn" style="background:var(--red-light);color:var(--red)"><i class="fas fa-file-pdf"></i> PDF</a>
    <a href="../api/cetak_jurnal.php?guru_id=<?= $guruId ?>&tgl_mulai=<?= $tglMulai ?>&tgl_selesai=<?= $tglSelesai ?>&format=excel" class="btn" style="background:var(--primary-light);color:var(--primary)"><i class="fas fa-file-excel"></i> Excel</a>
  </div>
</div>

<form method="GET" class="filter-bar" style="margin-bottom:16px">
  <div class="form-group"><label class="form-label">Dari</label><input type="date" name="tgl_mulai" class="form-control" value="<?= $tglMulai ?>"></div>
  <div class="form-group"><label class="form-label">Sampai</label><input type="date" name="tgl_selesai" class="form-control" value="<?= $tglSelesai ?>"></div>
  <div class="form-group" style="align-self:flex-end"><button type="submit" class="btn btn-outline"><i class="fas fa-search"></i> Cari</button></div>
</form>

<div class="card">
  <div class="table-wrap">
    <table>
      <thead><tr><th>Tanggal</th><th>Kelas &amp; Mapel</th><th>Materi</th><th>TTD</th><th>Aksi</th></tr></thead>
      <tbody>
      <?php foreach ($jurnals as $j): ?>
        <tr>
          <td><?= e($j['tanggal']) ?><br><small style="color:var(--slate-400)"><?= e($j['hari']) ?></small></td>
          <td><strong><?= e($j['mapel_nama']) ?></strong><br><small><?= e($j['kelas_nama']) ?> | <?= substr($j['jam_mulai'],0,5) ?>-<?= substr($j['jam_selesai'],0,5) ?></small></td>
          <td><?= e(substr($j['materi'],0,50)) ?><?= strlen($j['materi'])>50?'...':'' ?><br><small style="color:var(--slate-400)"><?= e(substr($j['kegiatan_pembelajaran']??'',0,40)) ?></small></td>
          <td><?= $j['ttd_guru'] ? '<img src="'.$j['ttd_guru'].'" style="max-height:40px">' : '<span style="color:var(--slate-400);font-size:12px">Belum TTD</span>' ?></td>
          <td><a href="jurnal.php?edit=<?= $j['id'] ?>&tgl_mulai=<?= $tglMulai ?>&tgl_selesai=<?= $tglSelesai ?>" class="btn-icon edit"><i class="fas fa-edit"></i></a></td>
        </tr>
      <?php endforeach; ?>
      <?php if (!$jurnals): ?><tr><td colspan="5" style="text-align:center;padding:32px;color:var(--slate-400)">Belum ada jurnal pada periode ini.</td></tr><?php endif; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Edit Modal -->
<div class="modal-overlay" id="modalEdit">
  <div class="modal modal-lg">
    <div class="modal-header"><span class="modal-title">Edit Jurnal Mengajar</span><button class="modal-close" onclick="closeModal('modalEdit')">&times;</button></div>
    <form method="POST">
      <input type="hidden" name="act" value="edit"><input type="hidden" name="id" value="<?= $editJurnal['id']??0 ?>">
      <input type="hidden" name="ttd_guru" id="ttd_edit_hidden" value="<?= e($editJurnal['ttd_guru']??'') ?>">
      <div class="modal-body">
        <div class="form-group"><label class="form-label">Materi Pelajaran</label>
          <input type="text" name="materi" class="form-control" value="<?= e($editJurnal['materi']??'') ?>"></div>
        <div class="form-group"><label class="form-label">Kegiatan Pembelajaran</label>
          <textarea name="kegiatan_pembelajaran" class="form-control" rows="3"><?= e($editJurnal['kegiatan_pembelajaran']??'') ?></textarea></div>
        <div class="form-group">
          <label class="form-label">Tanda Tangan Guru</label>
          <?php if (!empty($editJurnal['ttd_guru'])): ?>
          <div style="margin-bottom:8px"><img src="<?= $editJurnal['ttd_guru'] ?>" class="sig-preview"></div>
          <?php endif; ?>
          <div class="sig-wrap"><canvas id="sigEdit" width="500" height="100"></canvas></div>
          <div class="sig-actions"><button type="button" onclick="clearSignature('sigEdit','ttd_edit_hidden')" style="background:none;border:none;color:var(--red);cursor:pointer;font-size:12px"><i class="fas fa-trash"></i> Hapus</button></div>
        </div>
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline" onclick="closeModal('modalEdit')">Batal</button>
        <button type="submit" class="btn btn-primary">Simpan</button>
      </div>
    </form>
  </div>
</div>
<?php if ($editJurnal): ?><script>openModal('modalEdit');document.addEventListener('DOMContentLoaded',function(){initSignaturePad('sigEdit','ttd_edit_hidden');});</script><?php endif; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
