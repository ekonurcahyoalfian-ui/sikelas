<?php
session_start();
require_once __DIR__ . '/../includes/config.php';
requireGuru();
$pageTitle = 'Input Nilai';
$activePage = 'nilai';
$db = getDB();
$guruId = $_SESSION['user_id'];

if ($_SERVER['REQUEST_METHOD']==='POST') {
    $kelasId = (int)$_POST['kelas_id'];
    $mapelId = (int)$_POST['mapel_id'];
    $semester= $_POST['semester'] ?? 'Ganjil';
    foreach ($_POST['siswa_id']??[] as $siswaId) {
        $siswaId = (int)$siswaId;
        // Upsert nilai
        $db->prepare('INSERT INTO nilai(siswa_id,mapel_id,kelas_id,semester,nilai_asts,nilai_asas) VALUES(?,?,?,?,?,?) ON DUPLICATE KEY UPDATE nilai_asts=VALUES(nilai_asts),nilai_asas=VALUES(nilai_asas)')
           ->execute([$siswaId,$mapelId,$kelasId,$semester,$_POST['asts'][$siswaId]??null,$_POST['asas'][$siswaId]??null]);
        $nilaiId = $db->query('SELECT id FROM nilai WHERE siswa_id='.$siswaId.' AND mapel_id='.$mapelId.' AND kelas_id='.$kelasId.' AND semester=\''.$semester."'")->fetchColumn();
        // Hapus harian lama
        $db->prepare('DELETE FROM nilai_harian WHERE nilai_id=?')->execute([$nilaiId]);
        // Insert harian baru
        foreach ($_POST['harian'][$siswaId]??[] as $urut => $val) {
            if ($val !== '') $db->prepare('INSERT INTO nilai_harian(nilai_id,nilai,urutan) VALUES(?,?,?)')->execute([$nilaiId,(float)$val,$urut+1]);
        }
    }
    flash('ok','Nilai berhasil disimpan.');
    header('Location: nilai.php?kelas_id='.$kelasId.'&mapel_id='.$mapelId); exit;
}

$config  = getKonfigurasi();
$jadwals = $db->prepare('SELECT DISTINCT j.kelas_id,j.mapel_id,k.nama as kelas_nama,m.nama as mapel_nama FROM jadwal_pelajaran j JOIN kelas k ON k.id=j.kelas_id JOIN mapel m ON m.id=j.mapel_id WHERE j.guru_id=?');
$jadwals->execute([$guruId]); $jadwals = $jadwals->fetchAll();
$kelasList = array_unique(array_column($jadwals,'kelas_id'));
$mapelList = array_unique(array_column($jadwals,'mapel_id'));
$kelas = $db->query('SELECT * FROM kelas WHERE id IN('.implode(',',array_merge($kelasList,[0])).') ORDER BY nama')->fetchAll();
$mapels= $db->query('SELECT * FROM mapel WHERE id IN('.implode(',',array_merge($mapelList,[0])).') ORDER BY nama')->fetchAll();

$filterKelas = (int)($_GET['kelas_id'] ?? ($kelas[0]['id']??0));
$filterMapel = (int)($_GET['mapel_id'] ?? ($mapels[0]['id']??0));
$siswas = $filterKelas ? $db->query('SELECT * FROM siswa WHERE kelas_id='.$filterKelas.' ORDER BY nama')->fetchAll() : [];

function getNilaiSiswa($db,$siswaId,$mapelId,$kelasId) {
    $s = $db->prepare('SELECT n.*,GROUP_CONCAT(nh.nilai ORDER BY nh.urutan SEPARATOR ",") as harian_str FROM nilai n LEFT JOIN nilai_harian nh ON nh.nilai_id=n.id WHERE n.siswa_id=? AND n.mapel_id=? AND n.kelas_id=? GROUP BY n.id');
    $s->execute([$siswaId,$mapelId,$kelasId]); return $s->fetch();
}

include __DIR__ . '/../includes/header.php';
$ok = flash('ok');
?>
<?php if ($ok): ?><div class="alert alert-success alert-auto"><i class="fas fa-check-circle"></i> <?= e($ok) ?></div><?php endif; ?>

<div class="page-header">
  <div class="page-header-left"><h1>Input Nilai</h1><p>Masukkan nilai harian, ASTS, dan ASAS siswa</p></div>
</div>

<form method="GET" class="filter-bar" style="margin-bottom:16px">
  <div class="form-group"><label class="form-label">Kelas</label>
    <select name="kelas_id" class="form-control" onchange="this.form.submit()">
      <?php foreach ($kelas as $k): ?><option value="<?= $k['id'] ?>" <?= $filterKelas==$k['id']?'selected':'' ?>>Kelas <?= e($k['nama']) ?></option><?php endforeach; ?>
    </select></div>
  <div class="form-group"><label class="form-label">Mata Pelajaran</label>
    <select name="mapel_id" class="form-control" onchange="this.form.submit()">
      <?php foreach ($mapels as $m): ?><option value="<?= $m['id'] ?>" <?= $filterMapel==$m['id']?'selected':'' ?>><?= e($m['nama']) ?></option><?php endforeach; ?>
    </select></div>
</form>

<?php if ($siswas): ?>
<form method="POST">
  <input type="hidden" name="kelas_id" value="<?= $filterKelas ?>">
  <input type="hidden" name="mapel_id" value="<?= $filterMapel ?>">
  <input type="hidden" name="semester" value="<?= e($config['semester']) ?>">
  <div class="card">
    <div class="table-wrap">
      <table>
        <thead><tr><th>Siswa</th><th>Nilai Harian</th><th>Rata Harian</th><th>ASTS</th><th>ASAS</th><th>Nilai Akhir</th></tr></thead>
        <tbody>
        <?php foreach ($siswas as $s):
          $n = getNilaiSiswa($db,$s['id'],$filterMapel,$filterKelas);
          $harianArr = $n&&$n['harian_str'] ? array_map('floatval',explode(',',$n['harian_str'])) : [];
          $rataH = count($harianArr)?array_sum($harianArr)/count($harianArr):0;
          $asts  = $n?(float)$n['nilai_asts']:0;
          $asas  = $n?(float)$n['nilai_asas']:0;
          $akhir = $n?($rataH+$asts+$asas)/3:0;
        ?>
          <tr>
            <td><input type="hidden" name="siswa_id[]" value="<?= $s['id'] ?>"><strong><?= e($s['nama']) ?></strong><br><small><?= e($s['nisn']) ?></small></td>
            <td>
              <div id="harian_<?= $s['id'] ?>" style="display:flex;flex-wrap:wrap;gap:4px;align-items:center">
                <?php foreach ($harianArr as $idx=>$val): ?>
                <div class="nilai-harian-item" style="display:inline-flex;align-items:center;gap:4px">
                  <input type="number" name="harian[<?= $s['id'] ?>][]" min="0" max="100" value="<?= $val ?>" class="form-control" style="width:58px;padding:4px 8px;font-size:12px" onchange="updateRataHarian('<?= $s['id'] ?>')">
                  <button type="button" onclick="removeNilaiHarian(this,'<?= $s['id'] ?>')" style="background:none;border:none;color:var(--red);cursor:pointer">&times;</button>
                </div>
                <?php endforeach; ?>
                <button type="button" onclick="addNilaiHarian('<?= $s['id'] ?>')" class="btn btn-sm btn-outline" style="font-size:11px;padding:3px 8px"><i class="fas fa-plus"></i></button>
              </div>
            </td>
            <td style="text-align:center"><strong id="rata_<?= $s['id'] ?>"><?= count($harianArr)?number_format($rataH,1):'-' ?></strong></td>
            <td><input type="number" name="asts[<?= $s['id'] ?>]" id="asts_<?= $s['id'] ?>" min="0" max="100" value="<?= $n&&$n['nilai_asts']?number_format($asts,1):'' ?>" class="form-control" style="width:65px" placeholder="-" onchange="updateNilaiAkhir('<?= $s['id'] ?>')"></td>
            <td><input type="number" name="asas[<?= $s['id'] ?>]" id="asas_<?= $s['id'] ?>" min="0" max="100" value="<?= $n&&$n['nilai_asas']?number_format($asas,1):'' ?>" class="form-control" style="width:65px" placeholder="-" onchange="updateNilaiAkhir('<?= $s['id'] ?>')"></td>
            <td style="text-align:center"><strong id="akhir_<?= $s['id'] ?>" style="font-size:16px;color:<?= $n?($akhir>=75?'var(--primary)':'var(--red)'):'var(--slate-400)' ?>"><?= $n?number_format($akhir,1):'-' ?></strong></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>
  <div style="margin-top:16px">
    <button type="submit" class="btn btn-primary" style="padding:12px 28px"><i class="fas fa-save"></i> Simpan Nilai</button>
  </div>
</form>
<?php endif; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
