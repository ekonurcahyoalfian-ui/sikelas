<?php
session_start();
require_once __DIR__ . '/../includes/config.php';
requireGuru();
$pageTitle = 'Presensi & Jurnal';
$activePage = 'presensi';
$db = getDB();
$guruId = $_SESSION['user_id'];

$hariMap = [1=>'Senin',2=>'Selasa',3=>'Rabu',4=>'Kamis',5=>'Jumat',6=>'Sabtu',7=>'Minggu'];

// Save
if ($_SERVER['REQUEST_METHOD']==='POST') {
    $jadwalId = (int)$_POST['jadwal_id'];
    $tanggal  = $_POST['tanggal'];
    $materi   = trim($_POST['materi']??'');
    $kegiatan = trim($_POST['kegiatan_pembelajaran']??'');
    $ttdGuru  = $_POST['ttd_guru']??'';
    $statusArr= $_POST['status']??[];
    $catatanArr=$_POST['catatan']??[];

    // Presensi
    foreach ($statusArr as $siswaId => $status) {
        $catatan = $catatanArr[$siswaId]??'';
        $db->prepare('INSERT INTO presensi(jadwal_id,tanggal,siswa_id,status,catatan) VALUES(?,?,?,?,?) ON DUPLICATE KEY UPDATE status=VALUES(status),catatan=VALUES(catatan)')
           ->execute([$jadwalId,$tanggal,$siswaId,$status,$catatan]);
        // Jika Alpa, cek pelanggaran
        if ($status==='Alpa') {
            $jp = $db->query("SELECT id,poin_pengurangan FROM jenis_pelanggaran WHERE nama LIKE '%Membolos%' LIMIT 1")->fetch();
            if ($jp) {
                $dup = $db->prepare('SELECT id FROM pelanggaran WHERE siswa_id=? AND tanggal=? AND jenis_pelanggaran_id=?');
                $dup->execute([$siswaId,$tanggal,$jp['id']]);
                if (!$dup->fetchColumn()) {
                    $db->prepare('INSERT INTO pelanggaran(siswa_id,tanggal,jenis_pelanggaran_id,keterangan,poin_pengurangan) VALUES(?,?,?,?,?)')->execute([$siswaId,$tanggal,$jp['id'],$catatan,$jp['poin_pengurangan']]);
                    $db->prepare('UPDATE siswa SET poin=GREATEST(0,poin-?) WHERE id=?')->execute([$jp['poin_pengurangan'],$siswaId]);
                }
            }
        }
    }
    // Jurnal
    if ($materi) {
        $db->prepare('INSERT INTO jurnal_mengajar(jadwal_id,tanggal,materi,kegiatan_pembelajaran,ttd_guru,sudah_diisi) VALUES(?,?,?,?,?,1) ON DUPLICATE KEY UPDATE materi=VALUES(materi),kegiatan_pembelajaran=VALUES(kegiatan_pembelajaran),ttd_guru=VALUES(ttd_guru)')
           ->execute([$jadwalId,$tanggal,$materi,$kegiatan,$ttdGuru]);
    }
    flash('ok','Presensi dan jurnal berhasil disimpan.');
    header('Location: presensi.php?jadwal_id='.$jadwalId.'&tanggal='.$tanggal); exit;
}

$tanggal  = $_GET['tanggal'] ?? date('Y-m-d');
$selDay   = date('N', strtotime($tanggal));
$selHari  = $hariMap[$selDay] ?? 'Senin';
$jadwalId = (int)($_GET['jadwal_id'] ?? 0);

$jadwals = $db->prepare('SELECT j.*,k.nama as kelas_nama,m.nama as mapel_nama FROM jadwal_pelajaran j JOIN kelas k ON k.id=j.kelas_id JOIN mapel m ON m.id=j.mapel_id WHERE j.guru_id=? AND j.hari=? ORDER BY j.jam_mulai');
$jadwals->execute([$guruId,$selHari]);
$jadwals = $jadwals->fetchAll();

if (!$jadwalId && $jadwals) $jadwalId = $jadwals[0]['id'];
$jadwal = $jadwalId ? $db->query('SELECT j.*,k.nama as kelas_nama,m.nama as mapel_nama FROM jadwal_pelajaran j JOIN kelas k ON k.id=j.kelas_id JOIN mapel m ON m.id=j.mapel_id WHERE j.id='.$jadwalId)->fetch() : null;
$siswas = $jadwal ? $db->query('SELECT * FROM siswa WHERE kelas_id='.$jadwal['kelas_id'].' ORDER BY nama')->fetchAll() : [];

$existingPresensi = [];
if ($jadwal) {
    $ps = $db->prepare('SELECT * FROM presensi WHERE jadwal_id=? AND tanggal=?');
    $ps->execute([$jadwalId,$tanggal]);
    foreach ($ps->fetchAll() as $p) $existingPresensi[$p['siswa_id']] = $p;
}
$existingJurnal = null;
if ($jadwal) {
    $js = $db->prepare('SELECT * FROM jurnal_mengajar WHERE jadwal_id=? AND tanggal=?');
    $js->execute([$jadwalId,$tanggal]);
    $existingJurnal = $js->fetch();
}
$config = getKonfigurasi();
include __DIR__ . '/../includes/header.php';
$ok = flash('ok');
?>
<?php if ($ok): ?><div class="alert alert-success alert-auto"><i class="fas fa-check-circle"></i> <?= e($ok) ?></div><?php endif; ?>

<div class="page-header">
  <div class="page-header-left"><h1>Presensi &amp; Jurnal Mengajar</h1><p>Isi presensi siswa dan jurnal mengajar</p></div>
</div>

<!-- Selector -->
<div class="card" style="margin-bottom:16px">
  <div class="card-body">
    <form method="GET" class="filter-bar">
      <div class="form-group"><label class="form-label">Tanggal</label>
        <input type="date" name="tanggal" class="form-control" value="<?= $tanggal ?>" onchange="this.form.submit()"></div>
      <div class="form-group"><label class="form-label">Pilih Jadwal (<?= $selHari ?>)</label>
        <?php if ($jadwals): ?>
        <select name="jadwal_id" class="form-control" onchange="this.form.submit()">
          <?php foreach ($jadwals as $j): ?>
          <option value="<?= $j['id'] ?>" <?= $jadwalId==$j['id']?'selected':'' ?>><?= e($j['mapel_nama']) ?> - Kelas <?= e($j['kelas_nama']) ?> (<?= substr($j['jam_mulai'],0,5) ?>-<?= substr($j['jam_selesai'],0,5) ?>)</option>
          <?php endforeach; ?>
        </select>
        <?php else: ?>
        <div class="form-control" style="background:var(--slate-50);color:var(--slate-400)">Tidak ada jadwal pada hari <?= $selHari ?></div>
        <?php endif; ?>
      </div>
    </form>
  </div>
</div>

<?php if ($jadwal && $siswas): ?>
<!-- Info -->
<div class="alert alert-info" style="margin-bottom:16px">
  <i class="fas fa-info-circle"></i>
  <strong><?= e($jadwal['mapel_nama']) ?></strong> &mdash; Kelas <?= e($jadwal['kelas_nama']) ?> &mdash; <?= substr($jadwal['jam_mulai'],0,5) ?>&ndash;<?= substr($jadwal['jam_selesai'],0,5) ?> &mdash; <?= count($siswas) ?> siswa
</div>

<form method="POST">
  <input type="hidden" name="jadwal_id" value="<?= $jadwalId ?>">
  <input type="hidden" name="tanggal" value="<?= $tanggal ?>">
  <input type="hidden" name="ttd_guru" id="ttd_guru_hidden" value="<?= e($existingJurnal['ttd_guru']??'') ?>">

  <!-- Presensi -->
  <div class="card" style="margin-bottom:16px">
    <div class="card-header"><span class="card-title">Daftar Hadir Siswa</span></div>
    <div class="table-wrap">
      <table>
        <thead><tr><th>No</th><th>Nama Siswa</th><th>NISN</th><th>Status Kehadiran</th><th>Catatan / Pelanggaran</th></tr></thead>
        <tbody>
        <?php foreach ($siswas as $i => $s):
          $ep = $existingPresensi[$s['id']] ?? null;
          $curStatus = $ep['status'] ?? 'Hadir';
        ?>
          <tr>
            <td><?= $i+1 ?></td>
            <td><strong><?= e($s['nama']) ?></strong></td>
            <td><code><?= e($s['nisn']) ?></code></td>
            <td>
              <input type="hidden" name="status[<?= $s['id'] ?>]" id="status_<?= $s['id'] ?>" value="<?= $curStatus ?>">
              <div style="display:flex;gap:4px;flex-wrap:wrap">
                <?php foreach (['Hadir','Izin','Sakit','Alpa'] as $st): ?>
                <button type="button" class="status-btn <?= strtolower($st) ?> <?= $curStatus===$st?'active':'' ?>" data-siswa="<?= $s['id'] ?>" data-status="<?= $st ?>" onclick="setStatus('<?= $s['id'] ?>','<?= $st ?>');"><?= $st ?></button>
                <?php endforeach; ?>
              </div>
            </td>
            <td><input type="text" name="catatan[<?= $s['id'] ?>]" class="form-control" style="font-size:12px;padding:5px 8px" placeholder="Catatan pelanggaran..." value="<?= e($ep['catatan']??'') ?>"></td>
          </tr>
        <?php endforeach; ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Jurnal -->
  <div class="card" style="margin-bottom:16px">
    <div class="card-header"><span class="card-title">Jurnal Mengajar</span></div>
    <div class="card-body">
      <div class="form-group"><label class="form-label">Materi Pelajaran</label>
        <input type="text" name="materi" class="form-control" placeholder="Tulis materi yang diajarkan..." value="<?= e($existingJurnal['materi']??'') ?>"></div>
      <div class="form-group"><label class="form-label">Kegiatan Pembelajaran</label>
        <textarea name="kegiatan_pembelajaran" class="form-control" rows="3" placeholder="Deskripsikan kegiatan pembelajaran..."><?= e($existingJurnal['kegiatan_pembelajaran']??'') ?></textarea></div>
      <div class="form-group">
        <label class="form-label">Tanda Tangan Guru</label>
        <?php if (!empty($existingJurnal['ttd_guru'])): ?>
        <div style="margin-bottom:8px"><img src="<?= $existingJurnal['ttd_guru'] ?>" class="sig-preview"> <small style="color:var(--slate-400)">TTD tersimpan</small></div>
        <?php endif; ?>
        <div class="sig-wrap"><canvas id="sigGuru" width="500" height="120"></canvas></div>
        <div class="sig-actions">
          <button type="button" onclick="clearSignature('sigGuru','ttd_guru_hidden')" style="background:none;border:none;color:var(--red);cursor:pointer;font-size:12px"><i class="fas fa-trash"></i> Hapus TTD</button>
          <small style="color:var(--slate-400);margin-left:auto">Gambar tanda tangan di atas</small>
        </div>
      </div>
    </div>
  </div>

  <button type="submit" class="btn btn-primary" style="padding:12px 28px;font-size:15px">
    <i class="fas fa-save"></i> Simpan Presensi &amp; Jurnal
  </button>
</form>
<script>document.addEventListener('DOMContentLoaded',function(){initSignaturePad('sigGuru','ttd_guru_hidden');});</script>
<?php elseif ($jadwal): ?>
<div class="card"><div class="card-body" style="text-align:center;color:var(--slate-400);padding:40px">Tidak ada siswa di kelas ini.</div></div>
<?php endif; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
