<?php
session_start();
require_once __DIR__ . '/../includes/config.php';
requireGuru();
if (!$_SESSION['is_walas']) { header('Location: index.php'); exit; }
$pageTitle = 'Menu Wali Kelas';
$activePage = 'walas';
$db = getDB();
$guruId  = $_SESSION['user_id'];
$kelasId = (int)$_SESSION['kelas_wali_id'];

if ($_SERVER['REQUEST_METHOD']==='POST') {
    $act = $_POST['act']??'';
    if ($act==='catat_pelanggaran') {
        $siswaId = (int)$_POST['siswa_id'];
        $jenisId = (int)$_POST['jenis_pelanggaran_id'];
        $tgl     = $_POST['tanggal'];
        $ket     = $_POST['keterangan']??'';
        $jp      = $db->query('SELECT poin_pengurangan FROM jenis_pelanggaran WHERE id='.$jenisId)->fetchColumn();
        $db->prepare('INSERT INTO pelanggaran(siswa_id,tanggal,jenis_pelanggaran_id,keterangan,poin_pengurangan) VALUES(?,?,?,?,?)')->execute([$siswaId,$tgl,$jenisId,$ket,$jp]);
        $db->prepare('UPDATE siswa SET poin=GREATEST(0,poin-?) WHERE id=?')->execute([$jp,$siswaId]);
        flash('ok','Pelanggaran berhasil dicatat.');
    }
    header('Location: walas.php'); exit;
}

$kelas   = $db->query('SELECT * FROM kelas WHERE id='.$kelasId)->fetch();
$siswas  = $db->query('SELECT * FROM siswa WHERE kelas_id='.$kelasId.' ORDER BY nama')->fetchAll();
$jenisPelanggaran = $db->query('SELECT * FROM jenis_pelanggaran ORDER BY kategori,nama')->fetchAll();
$mapelList = $db->query('SELECT * FROM mapel ORDER BY nama')->fetchAll();
include __DIR__ . '/../includes/header.php';
$ok = flash('ok');
?>
<?php if ($ok): ?><div class="alert alert-success alert-auto"><i class="fas fa-check-circle"></i> <?= e($ok) ?></div><?php endif; ?>

<div class="page-header">
  <div class="page-header-left"><h1>Menu Wali Kelas</h1><p>Kelas <?= e($kelas['nama']??'-') ?> &mdash; <?= count($siswas) ?> Siswa</p></div>
</div>

<div class="stats-grid" style="grid-template-columns:repeat(4,1fr)">
  <?php
  $poinBaik = count(array_filter($siswas,fn($s)=>$s['poin']>=80));
  $poinSedang = count(array_filter($siswas,fn($s)=>$s['poin']>=60&&$s['poin']<80));
  $poinKritis = count(array_filter($siswas,fn($s)=>$s['poin']<60));
  ?>
  <div class="stat-card"><div class="stat-icon bg-blue"><i class="fas fa-users text-blue"></i></div><div class="stat-value text-blue"><?= count($siswas) ?></div><div class="stat-label">Total Siswa</div></div>
  <div class="stat-card"><div class="stat-icon bg-emerald"><i class="fas fa-smile text-emerald"></i></div><div class="stat-value text-emerald"><?= $poinBaik ?></div><div class="stat-label">Poin Baik (&ge;80)</div></div>
  <div class="stat-card"><div class="stat-icon bg-amber"><i class="fas fa-meh text-amber"></i></div><div class="stat-value text-amber"><?= $poinSedang ?></div><div class="stat-label">Perlu Perhatian</div></div>
  <div class="stat-card"><div class="stat-icon bg-red"><i class="fas fa-frown text-red"></i></div><div class="stat-value text-red"><?= $poinKritis ?></div><div class="stat-label">Kritis (&lt;60)</div></div>
</div>

<div class="card">
  <div class="table-wrap">
    <table>
      <thead><tr><th>Siswa</th><th>NISN</th><th>Poin</th><th>Pelanggaran</th><th>Aksi</th></tr></thead>
      <tbody>
      <?php foreach ($siswas as $s):
        $jmlP = $db->query('SELECT COUNT(*) FROM pelanggaran WHERE siswa_id='.$s['id'])->fetchColumn();
        $pc = $s['poin']>=80?'badge-emerald':($s['poin']>=60?'badge-amber':'badge-red');
      ?>
        <tr>
          <td><div class="user-cell"><div class="avatar avatar-violet"><?= strtoupper(substr($s['nama'],0,1)) ?></div><span class="user-cell-name"><?= e($s['nama']) ?></span></div></td>
          <td><code><?= e($s['nisn']) ?></code></td>
          <td><span class="badge <?= $pc ?>"><?= $s['poin'] ?></span></td>
          <td><span style="color:<?= $jmlP>0?'var(--red)':'var(--slate-400)' ?>;font-weight:<?= $jmlP>0?'600':'400' ?>"><?= $jmlP ?>x</span></td>
          <td>
            <div class="btn-group">
              <a href="?detail=<?= $s['id'] ?>" class="btn btn-sm btn-outline"><i class="fas fa-user"></i> Detail</a>
              <a href="?catat=<?= $s['id'] ?>" class="btn btn-sm" style="background:var(--red-light);color:var(--red)"><i class="fas fa-exclamation-triangle"></i> Catat</a>
            </div>
          </td>
        </tr>
      <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<!-- Detail Modal -->
<?php if (isset($_GET['detail'])):
  $ds = $db->query('SELECT * FROM siswa WHERE id='.(int)$_GET['detail'])->fetch();
  $nilaiSiswa = $db->query('SELECT n.*,m.nama as mapel_nama,GROUP_CONCAT(nh.nilai ORDER BY nh.urutan) as harian_str FROM nilai n JOIN mapel m ON m.id=n.mapel_id LEFT JOIN nilai_harian nh ON nh.nilai_id=n.id WHERE n.siswa_id='.(int)$_GET['detail'].' GROUP BY n.id')->fetchAll();
  $pelSiswa = $db->query('SELECT p.*,j.nama as jenis_nama FROM pelanggaran p JOIN jenis_pelanggaran j ON j.id=p.jenis_pelanggaran_id WHERE p.siswa_id='.(int)$_GET['detail'].' ORDER BY p.tanggal DESC')->fetchAll();
?>
<div class="modal-overlay open" id="modalDetail">
  <div class="modal modal-lg">
    <div class="modal-header"><span class="modal-title">Profil: <?= e($ds['nama']??'') ?></span><a href="walas.php" class="modal-close">&times;</a></div>
    <div class="modal-body">
      <div style="display:flex;gap:16px;margin-bottom:20px;align-items:flex-start">
        <div class="avatar avatar-violet" style="width:56px;height:56px;font-size:22px;border-radius:14px"><?= strtoupper(substr($ds['nama'],0,1)) ?></div>
        <div style="flex:1">
          <h3 style="margin:0"><?= e($ds['nama']) ?></h3>
          <p style="color:var(--slate-500);font-size:13px;margin:4px 0">NISN: <?= e($ds['nisn']) ?></p>
          <p style="color:var(--slate-500);font-size:13px">Ayah: <?= e($ds['nama_ayah']??'-') ?> | Ibu: <?= e($ds['nama_ibu']??'-') ?></p>
        </div>
        <div style="text-align:right">
          <?php $pc2=$ds['poin']>=80?'var(--primary)':($ds['poin']>=60?'var(--amber)':'var(--red)'); ?>
          <div style="font-size:32px;font-weight:700;color:<?= $pc2 ?>"><?= $ds['poin'] ?></div>
          <div style="font-size:12px;color:var(--slate-500)">Poin Perilaku</div>
        </div>
      </div>
      <?php if ($nilaiSiswa): ?>
      <h4 style="margin-bottom:12px">Analisis Nilai</h4>
      <?php foreach ($nilaiSiswa as $n):
        $harr=array_map('floatval',explode(',',$n['harian_str']??''));
        $rH=count($harr)?array_sum($harr)/count($harr):0;
        $akhir=($rH+(float)$n['nilai_asts']+(float)$n['nilai_asas'])/3;
        $bc=$akhir>=75?'var(--primary)':'var(--red)';
      ?>
      <div style="margin-bottom:10px">
        <div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:4px">
          <span><?= e($n['mapel_nama']) ?></span>
          <strong style="color:<?= $bc ?>"><?= number_format($akhir,1) ?></strong>
        </div>
        <div class="nilai-bar-wrap"><div class="nilai-bar" style="width:<?= min($akhir,100) ?>%;background:<?= $bc ?>"></div></div>
        <?php if ($akhir<75): ?><small style="color:var(--amber)">&#9888; Perlu ditingkatkan</small><?php endif; ?>
      </div>
      <?php endforeach; endif; ?>
      <?php if ($pelSiswa): ?>
      <h4 style="margin:16px 0 10px">Riwayat Pelanggaran</h4>
      <?php foreach ($pelSiswa as $p): ?>
      <div style="display:flex;justify-content:space-between;padding:8px 12px;background:var(--red-light);border-radius:8px;margin-bottom:6px;font-size:13px">
        <div><strong><?= e($p['jenis_nama']) ?></strong><br><small><?= e($p['tanggal']) ?> &mdash; <?= e($p['keterangan']??'') ?></small></div>
        <span style="color:var(--red);font-weight:700">-<?= $p['poin_pengurangan'] ?></span>
      </div>
      <?php endforeach; endif; ?>
    </div>
  </div>
</div>
<?php endif; ?>

<!-- Catat Pelanggaran -->
<?php if (isset($_GET['catat'])):
  $cs = $db->query('SELECT * FROM siswa WHERE id='.(int)$_GET['catat'])->fetch();
?>
<div class="modal-overlay open">
  <div class="modal">
    <div class="modal-header"><span class="modal-title">Catat Pelanggaran: <?= e($cs['nama']??'') ?></span><a href="walas.php" class="modal-close">&times;</a></div>
    <form method="POST">
      <input type="hidden" name="act" value="catat_pelanggaran">
      <input type="hidden" name="siswa_id" value="<?= $cs['id'] ?>">
      <div class="modal-body">
        <div class="form-group"><label class="form-label">Tanggal</label><input type="date" name="tanggal" class="form-control" value="<?= date('Y-m-d') ?>"></div>
        <div class="form-group"><label class="form-label">Jenis Pelanggaran</label>
          <select name="jenis_pelanggaran_id" class="form-control" required>
            <option value="">-- Pilih Jenis --</option>
            <?php foreach ($jenisPelanggaran as $j): ?>
            <option value="<?= $j['id'] ?>"><?= e($j['nama']) ?> (-<?= $j['poin_pengurangan'] ?> poin)</option>
            <?php endforeach; ?>
          </select></div>
        <div class="form-group"><label class="form-label">Keterangan</label><textarea name="keterangan" class="form-control" rows="2" placeholder="Keterangan tambahan..."></textarea></div>
      </div>
      <div class="modal-footer">
        <a href="walas.php" class="btn btn-outline">Batal</a>
        <button type="submit" class="btn btn-red">Catat Pelanggaran</button>
      </div>
    </form>
  </div>
</div>
<?php endif; ?>
<?php include __DIR__ . '/../includes/footer.php'; ?>
