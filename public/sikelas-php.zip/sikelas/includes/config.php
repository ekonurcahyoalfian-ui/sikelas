<?php
// ============================================================
//  SiKelas - Konfigurasi Database
//  Copyright © 2026 RUMAHIMI — Sistem Manajemen Kelas
// ============================================================

define('DB_HOST', 'localhost');
define('DB_USER', 'root');       // Ganti sesuai user MySQL Anda
define('DB_PASS', '');           // Ganti sesuai password MySQL Anda
define('DB_NAME', 'sikelas');
define('APP_NAME', 'SiKelas');
define('APP_VERSION', '1.0.0');
define('COPYRIGHT', 'Copyright &copy; 2026 RUMAHIMI &mdash; Sistem Manajemen Kelas');

// BASE_URL otomatis — bekerja di localhost, IP jaringan, maupun domain hosting
(function() {
    $protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off') ? 'https' : 'http';
    $host     = $_SERVER['HTTP_HOST'] ?? 'localhost';          // otomatis: localhost / 192.168.x.x / domain.com
    $script   = $_SERVER['SCRIPT_NAME'] ?? '/sikelas/index.php';
    // Ambil folder root aplikasi (folder "sikelas")
    $parts    = explode('/', trim($script, '/'));
    $appFolder = $parts[0] ?? 'sikelas';                       // "sikelas"
    define('BASE_URL', $protocol . '://' . $host . '/' . $appFolder . '/');
})();

// Koneksi PDO
function getDB(): PDO {
    static $pdo = null;
    if ($pdo === null) {
        try {
            $dsn = 'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4';
            $pdo = new PDO($dsn, DB_USER, DB_PASS, [
                PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
                PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                PDO::ATTR_EMULATE_PREPARES   => false,
            ]);
        } catch (PDOException $e) {
            die('<div style="font-family:sans-serif;padding:40px;background:#fee2e2;border:1px solid #fca5a5;border-radius:8px;max-width:600px;margin:40px auto">
                <h2 style="color:#dc2626">❌ Koneksi Database Gagal</h2>
                <p><strong>Error:</strong> ' . htmlspecialchars($e->getMessage()) . '</p>
                <p>Pastikan:</p><ul>
                <li>XAMPP MySQL sudah berjalan</li>
                <li>Database <strong>sikelas</strong> sudah dibuat (import database.sql)</li>
                <li>Username/password di <code>includes/config.php</code> sudah benar</li>
                </ul></div>');
        }
    }
    return $pdo;
}

// Fungsi helper
function getKonfigurasi(): array {
    $db = getDB();
    $row = $db->query('SELECT * FROM konfigurasi LIMIT 1')->fetch();
    return $row ?: [];
}

function isLoggedIn(): bool {
    return isset($_SESSION['user_id']);
}

function requireLogin(): void {
    if (!isLoggedIn()) {
        header('Location: ' . BASE_URL . 'login.php');
        exit;
    }
}

function requireAdmin(): void {
    requireLogin();
    if ($_SESSION['role'] !== 'admin') {
        header('Location: ' . BASE_URL . 'guru/index.php');
        exit;
    }
}

function requireGuru(): void {
    requireLogin();
    if ($_SESSION['role'] !== 'guru') {
        header('Location: ' . BASE_URL . 'admin/index.php');
        exit;
    }
}

function flash(string $key, string $msg = ''): string {
    if ($msg) {
        $_SESSION['flash'][$key] = $msg;
        return '';
    }
    $val = $_SESSION['flash'][$key] ?? '';
    unset($_SESSION['flash'][$key]);
    return $val;
}

function e(string $s): string {
    return htmlspecialchars($s, ENT_QUOTES, 'UTF-8');
}

function formatTanggal(string $tgl): string {
    $bulan = ['','Januari','Februari','Maret','April','Mei','Juni',
              'Juli','Agustus','September','Oktober','November','Desember'];
    $t = explode('-', $tgl);
    return ($t[2] ?? '') . ' ' . ($bulan[(int)($t[1] ?? 0)] ?? '') . ' ' . ($t[0] ?? '');
}
