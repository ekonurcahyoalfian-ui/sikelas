<?php $config = $config ?? getKonfigurasi(); ?>
  </div><!-- end page-content -->
  <footer class="page-footer">
    <span><?= COPYRIGHT ?></span>
  </footer>
</div><!-- end main-wrapper -->

<script src="<?= BASE_URL ?>assets/js/app.js?v=2"></script>
</body>
</html>
