<?php
$config = getKonfigurasi();
$activeUser = $_SESSION['nama'] ?? '';
$activeRole = $_SESSION['role'] ?? '';
$activePage = $activePage ?? '';
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <meta name="mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="theme-color" content="#1e293b">
  <title><?= e($pageTitle ?? 'Dashboard') ?> &mdash; <?= APP_NAME ?></title>
  <link rel="icon" href="<?= BASE_URL ?>assets/img/logo.png" type="image/png">
  <link rel="stylesheet" href="<?= BASE_URL ?>assets/css/style.css?v=2">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>

<!-- Sidebar -->
<div class="sidebar" id="sidebar">
  <div class="sidebar-header">
    <img src="<?= BASE_URL ?>assets/img/logo.png" alt="SiKelas" class="sidebar-logo">
    <div class="sidebar-brand">
      <span class="brand-name">SiKelas</span>
      <span class="brand-sub">Manajemen Kelas</span>
    </div>
  </div>

  <div class="sidebar-user">
    <div class="user-avatar"><?= strtoupper(substr($activeUser, 0, 1)) ?></div>
    <div class="user-info">
      <div class="user-name"><?= e($activeUser) ?></div>
      <div class="user-role"><?= $activeRole === 'admin' ? 'Administrator' : (($_SESSION['is_walas'] ?? 0) ? 'Guru / Wali Kelas' : 'Guru') ?></div>
    </div>
  </div>

  <nav class="sidebar-nav">
    <?php if ($activeRole === 'admin'): ?>
    <a href="<?= BASE_URL ?>admin/index.php" class="nav-item <?= $activePage==='dashboard'?'active':'' ?>">
      <i class="fas fa-th-large"></i><span>Dashboard</span>
    </a>
    <div class="nav-group">
      <div class="nav-group-title">Data Master</div>
      <a href="<?= BASE_URL ?>admin/kelas.php" class="nav-item <?= $activePage==='kelas'?'active':'' ?>">
        <i class="fas fa-school"></i><span>Kelas</span>
      </a>
      <a href="<?= BASE_URL ?>admin/mapel.php" class="nav-item <?= $activePage==='mapel'?'active':'' ?>">
        <i class="fas fa-book"></i><span>Mata Pelajaran</span>
      </a>
      <a href="<?= BASE_URL ?>admin/guru.php" class="nav-item <?= $activePage==='guru'?'active':'' ?>">
        <i class="fas fa-chalkboard-teacher"></i><span>Guru</span>
      </a>
      <a href="<?= BASE_URL ?>admin/siswa.php" class="nav-item <?= $activePage==='siswa'?'active':'' ?>">
        <i class="fas fa-user-graduate"></i><span>Siswa</span>
      </a>
      <a href="<?= BASE_URL ?>admin/mapel_kelas.php" class="nav-item <?= $activePage==='mapel_kelas'?'active':'' ?>">
        <i class="fas fa-layer-group"></i><span>Mapel per Kelas</span>
      </a>
    </div>
    <div class="nav-group">
      <div class="nav-group-title">Akademik</div>
      <a href="<?= BASE_URL ?>admin/jadwal.php" class="nav-item <?= $activePage==='jadwal'?'active':'' ?>">
        <i class="fas fa-calendar-alt"></i><span>Jadwal Pelajaran</span>
      </a>
      <a href="<?= BASE_URL ?>admin/rekap_presensi.php" class="nav-item <?= $activePage==='rekap_presensi'?'active':'' ?>">
        <i class="fas fa-clipboard-list"></i><span>Rekap Presensi</span>
      </a>
      <a href="<?= BASE_URL ?>admin/rekap_jurnal.php" class="nav-item <?= $activePage==='rekap_jurnal'?'active':'' ?>">
        <i class="fas fa-file-alt"></i><span>Rekap Jurnal</span>
      </a>
      <a href="<?= BASE_URL ?>admin/rekap_nilai.php" class="nav-item <?= $activePage==='rekap_nilai'?'active':'' ?>">
        <i class="fas fa-star"></i><span>Rekap Nilai</span>
      </a>
    </div>
    <a href="<?= BASE_URL ?>admin/pelanggaran.php" class="nav-item <?= $activePage==='pelanggaran'?'active':'' ?>">
      <i class="fas fa-exclamation-triangle"></i><span>Pelanggaran</span>
    </a>
    <a href="<?= BASE_URL ?>admin/konfigurasi.php" class="nav-item <?= $activePage==='konfigurasi'?'active':'' ?>">
      <i class="fas fa-cog"></i><span>Konfigurasi</span>
    </a>
    <?php else: ?>
    <a href="<?= BASE_URL ?>guru/index.php" class="nav-item <?= $activePage==='dashboard'?'active':'' ?>">
      <i class="fas fa-th-large"></i><span>Dashboard</span>
    </a>
    <a href="<?= BASE_URL ?>guru/presensi.php" class="nav-item <?= $activePage==='presensi'?'active':'' ?>">
      <i class="fas fa-clipboard-check"></i><span>Presensi &amp; Jurnal</span>
    </a>
    <a href="<?= BASE_URL ?>guru/jurnal.php" class="nav-item <?= $activePage==='jurnal'?'active':'' ?>">
      <i class="fas fa-book-open"></i><span>Jurnal Mengajar</span>
    </a>
    <a href="<?= BASE_URL ?>guru/nilai.php" class="nav-item <?= $activePage==='nilai'?'active':'' ?>">
      <i class="fas fa-star"></i><span>Input Nilai</span>
    </a>
    <?php if ($_SESSION['is_walas'] ?? 0): ?>
    <a href="<?= BASE_URL ?>guru/walas.php" class="nav-item <?= $activePage==='walas'?'active':'' ?>">
      <i class="fas fa-user-check"></i><span>Menu Wali Kelas</span>
    </a>
    <?php endif; ?>
    <?php endif; ?>
  </nav>

  <div class="sidebar-footer">
    <a href="<?= BASE_URL ?>logout.php" class="nav-item nav-logout">
      <i class="fas fa-sign-out-alt"></i><span>Keluar</span>
    </a>
  </div>
</div>

<!-- Overlay mobile -->
<div class="sidebar-overlay" id="sidebarOverlay" onclick="closeSidebar()"></div>

<!-- Main -->
<div class="main-wrapper">
  <div class="topbar">
    <button class="topbar-toggle" onclick="toggleSidebar()"><i class="fas fa-bars"></i></button>
    <div class="topbar-title"><?= e($pageTitle ?? 'Dashboard') ?></div>
    <div class="topbar-right">
      <span class="topbar-user"><i class="fas fa-user-circle"></i> <?= e($activeUser) ?></span>
    </div>
  </div>
  <div class="page-content">
