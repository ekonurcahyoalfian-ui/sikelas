<?php
session_start();
require_once __DIR__ . '/includes/config.php';
if (!isLoggedIn()) { header('Location: login.php'); exit; }
if ($_SESSION['role'] === 'admin') { header('Location: admin/index.php'); exit; }
header('Location: guru/index.php'); exit;
