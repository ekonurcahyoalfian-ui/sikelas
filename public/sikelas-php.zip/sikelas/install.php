<?php
// ============================================================
//  SiKelas - Installer (FIXED)
//  Jalankan sekali untuk setup database
//  Hapus file ini setelah instalasi selesai!
// ============================================================

$host = 'localhost';
$user = 'root';
$pass = '';        // Ganti jika MySQL Anda punya password

try {
    // Koneksi tanpa pilih database dulu
    $pdo = new PDO(
        "mysql:host=$host;charset=utf8mb4",
        $user, $pass,
        [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
    );

    // Buat database
    $pdo->exec("CREATE DATABASE IF NOT EXISTS `sikelas` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci");
    $pdo->exec("USE `sikelas`");

    // Buat semua tabel
    $tables = [
        "CREATE TABLE IF NOT EXISTS `users` (
          `id` INT AUTO_INCREMENT PRIMARY KEY,
          `nama` VARCHAR(150) NOT NULL,
          `username` VARCHAR(80) NOT NULL UNIQUE,
          `password` VARCHAR(255) NOT NULL,
          `role` ENUM('admin','guru') NOT NULL DEFAULT 'guru',
          `is_walas` TINYINT(1) DEFAULT 0,
          `kelas_wali_id` INT DEFAULT NULL,
          `ttd` LONGTEXT DEFAULT NULL,
          `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB",

        "CREATE TABLE IF NOT EXISTS `kelas` (
          `id` INT AUTO_INCREMENT PRIMARY KEY,
          `nama` VARCHAR(50) NOT NULL,
          `tahun_ajaran` VARCHAR(20) NOT NULL DEFAULT '2025/2026',
          `wali_kelas_id` INT DEFAULT NULL,
          `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB",

        "CREATE TABLE IF NOT EXISTS `mapel` (
          `id` INT AUTO_INCREMENT PRIMARY KEY,
          `nama` VARCHAR(100) NOT NULL,
          `kode` VARCHAR(20) NOT NULL,
          `jp_per_pekan` INT DEFAULT 2,
          `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB",

        "CREATE TABLE IF NOT EXISTS `mapel_kelas` (
          `id` INT AUTO_INCREMENT PRIMARY KEY,
          `kelas_id` INT NOT NULL,
          `mapel_id` INT NOT NULL,
          `guru_id` INT NOT NULL,
          UNIQUE KEY `uq_kelas_mapel` (`kelas_id`,`mapel_id`)
        ) ENGINE=InnoDB",

        "CREATE TABLE IF NOT EXISTS `siswa` (
          `id` INT AUTO_INCREMENT PRIMARY KEY,
          `nama` VARCHAR(150) NOT NULL,
          `nisn` VARCHAR(20) NOT NULL UNIQUE,
          `alamat` TEXT DEFAULT NULL,
          `nama_ayah` VARCHAR(100) DEFAULT NULL,
          `nama_ibu` VARCHAR(100) DEFAULT NULL,
          `kelas_id` INT DEFAULT NULL,
          `poin` INT DEFAULT 100,
          `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB",

        "CREATE TABLE IF NOT EXISTS `jadwal_pelajaran` (
          `id` INT AUTO_INCREMENT PRIMARY KEY,
          `kelas_id` INT NOT NULL,
          `mapel_id` INT NOT NULL,
          `guru_id` INT NOT NULL,
          `hari` ENUM('Senin','Selasa','Rabu','Kamis','Jumat','Sabtu') NOT NULL,
          `jam_mulai` TIME NOT NULL,
          `jam_selesai` TIME NOT NULL
        ) ENGINE=InnoDB",

        "CREATE TABLE IF NOT EXISTS `presensi` (
          `id` INT AUTO_INCREMENT PRIMARY KEY,
          `jadwal_id` INT NOT NULL,
          `tanggal` DATE NOT NULL,
          `siswa_id` INT NOT NULL,
          `status` ENUM('Hadir','Izin','Sakit','Alpa') NOT NULL DEFAULT 'Hadir',
          `catatan` TEXT DEFAULT NULL,
          UNIQUE KEY `uq_presensi` (`jadwal_id`,`tanggal`,`siswa_id`)
        ) ENGINE=InnoDB",

        "CREATE TABLE IF NOT EXISTS `jurnal_mengajar` (
          `id` INT AUTO_INCREMENT PRIMARY KEY,
          `jadwal_id` INT NOT NULL,
          `tanggal` DATE NOT NULL,
          `materi` TEXT NOT NULL,
          `kegiatan_pembelajaran` TEXT DEFAULT NULL,
          `ttd_guru` LONGTEXT DEFAULT NULL,
          `sudah_diisi` TINYINT(1) DEFAULT 1,
          UNIQUE KEY `uq_jurnal` (`jadwal_id`,`tanggal`)
        ) ENGINE=InnoDB",

        "CREATE TABLE IF NOT EXISTS `jenis_pelanggaran` (
          `id` INT AUTO_INCREMENT PRIMARY KEY,
          `nama` VARCHAR(200) NOT NULL,
          `kategori` ENUM('Ringan','Sedang','Berat') NOT NULL DEFAULT 'Ringan',
          `poin_pengurangan` INT NOT NULL DEFAULT 5
        ) ENGINE=InnoDB",

        "CREATE TABLE IF NOT EXISTS `pelanggaran` (
          `id` INT AUTO_INCREMENT PRIMARY KEY,
          `siswa_id` INT NOT NULL,
          `tanggal` DATE NOT NULL,
          `jenis_pelanggaran_id` INT NOT NULL,
          `keterangan` TEXT DEFAULT NULL,
          `poin_pengurangan` INT NOT NULL,
          `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        ) ENGINE=InnoDB",

        "CREATE TABLE IF NOT EXISTS `nilai` (
          `id` INT AUTO_INCREMENT PRIMARY KEY,
          `siswa_id` INT NOT NULL,
          `mapel_id` INT NOT NULL,
          `kelas_id` INT NOT NULL,
          `semester` VARCHAR(20) DEFAULT 'Ganjil',
          `nilai_asts` DECIMAL(5,2) DEFAULT NULL,
          `nilai_asas` DECIMAL(5,2) DEFAULT NULL,
          UNIQUE KEY `uq_nilai` (`siswa_id`,`mapel_id`,`kelas_id`,`semester`)
        ) ENGINE=InnoDB",

        "CREATE TABLE IF NOT EXISTS `nilai_harian` (
          `id` INT AUTO_INCREMENT PRIMARY KEY,
          `nilai_id` INT NOT NULL,
          `nilai` DECIMAL(5,2) NOT NULL,
          `urutan` INT DEFAULT 1
        ) ENGINE=InnoDB",

        "CREATE TABLE IF NOT EXISTS `konfigurasi` (
          `id` INT AUTO_INCREMENT PRIMARY KEY,
          `nama_sekolah` VARCHAR(200) DEFAULT 'SMP Negeri 1',
          `alamat_sekolah` TEXT DEFAULT 'Jl. Pendidikan No. 1',
          `nama_kepsek` VARCHAR(150) DEFAULT 'Drs. Ahmad Fauzi, M.Pd',
          `ttd_kepsek` LONGTEXT DEFAULT NULL,
          `tahun_ajaran` VARCHAR(20) DEFAULT '2025/2026',
          `semester` ENUM('Ganjil','Genap') DEFAULT 'Ganjil'
        ) ENGINE=InnoDB",
    ];

    foreach ($tables as $sql) {
        $pdo->exec($sql);
    }

    // Insert konfigurasi default (jika belum ada)
    $pdo->exec("INSERT IGNORE INTO konfigurasi (id, nama_sekolah, alamat_sekolah, nama_kepsek, tahun_ajaran, semester)
                VALUES (1, 'SMP Negeri 1', 'Jl. Pendidikan No. 1', 'Drs. Ahmad Fauzi, M.Pd', '2025/2026', 'Ganjil')");

    // Insert jenis pelanggaran default
    $jenisList = [
        ['Terlambat masuk sekolah',        'Ringan', 3],
        ['Tidak membawa buku pelajaran',   'Ringan', 2],
        ['Tidak mengerjakan PR',            'Ringan', 5],
        ['Berpakaian tidak rapi',           'Ringan', 3],
        ['Membolos pelajaran',              'Sedang', 10],
        ['Berkelahi',                       'Berat',  25],
        ['Merokok di lingkungan sekolah',   'Berat',  30],
        ['Merusak fasilitas sekolah',       'Sedang', 15],
        ['Tidak hormat kepada guru',        'Sedang', 10],
        ['Membawa HP tanpa izin',           'Ringan', 5],
    ];
    $stmtJ = $pdo->prepare("INSERT IGNORE INTO jenis_pelanggaran (nama, kategori, poin_pengurangan) VALUES (?, ?, ?)");
    foreach ($jenisList as $j) {
        $stmtJ->execute($j);
    }

    // Buat/update akun admin dengan password yang benar
    $hash = password_hash('admin123', PASSWORD_DEFAULT);
    $cek  = $pdo->query("SELECT id FROM users WHERE username='admin' LIMIT 1")->fetchColumn();
    if ($cek) {
        $pdo->prepare("UPDATE users SET password=? WHERE username='admin'")->execute([$hash]);
        $adminAction = 'diperbarui';
    } else {
        $pdo->prepare("INSERT INTO users (nama, username, password, role) VALUES ('Administrator', 'admin', ?, 'admin')")->execute([$hash]);
        $adminAction = 'dibuat';
    }

    // Tampilkan hasil
    ?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <title>Instalasi SiKelas</title>
  <style>
    body { font-family: 'Segoe UI', Arial, sans-serif; background: #f1f5f9; margin: 0; padding: 40px 20px; }
    .box { max-width: 560px; margin: 0 auto; }
    .card { background: #fff; border-radius: 16px; padding: 28px; margin-bottom: 16px; box-shadow: 0 2px 8px rgba(0,0,0,.08); }
    .success { background: #d1fae5; border: 1px solid #6ee7b7; }
    h2 { margin: 0 0 8px; font-size: 20px; }
    p  { margin: 6px 0; font-size: 14px; color: #334155; }
    ol { padding-left: 20px; line-height: 2.2; font-size: 14px; }
    code { background: #1e293b; color: #34d399; padding: 3px 10px; border-radius: 6px; font-size: 13px; }
    .btn { display: inline-block; margin-top: 20px; padding: 12px 28px; background: #059669; color: #fff;
           border-radius: 10px; text-decoration: none; font-weight: 600; font-size: 15px; }
    .btn:hover { background: #047857; }
    .warn { background: #fef3c7; border: 1px solid #fcd34d; border-radius: 10px; padding: 12px 16px;
            font-size: 13px; color: #92400e; margin-top: 12px; }
    small { color: #94a3b8; font-size: 12px; }
  </style>
</head>
<body>
<div class="box">
  <div style="text-align:center;margin-bottom:24px">
    <img src="assets/img/logo.png" style="width:64px;border-radius:12px" onerror="this.style.display='none'">
    <h1 style="margin:8px 0 0;font-size:26px;color:#1e293b">SiKelas</h1>
  </div>

  <div class="card success">
    <h2 style="color:#059669">&#10003; Instalasi Berhasil!</h2>
    <p>Database <strong>sikelas</strong> berhasil disiapkan.</p>
    <p>Akun admin berhasil <strong><?= $adminAction ?>.</strong></p>
  </div>

  <div class="card">
    <h2>&#128272; Akun Login</h2>
    <p>Username : <code>admin</code></p>
    <p>Password : <code>admin123</code></p>
  </div>

  <div class="card">
    <h2>&#128203; Langkah Selanjutnya</h2>
    <ol>
      <li>Hapus file <code>install.php</code> dari server</li>
      <li>Klik tombol di bawah untuk masuk</li>
    </ol>
    <a href="login.php" class="btn">&#8594; Buka Halaman Login</a>
  </div>

  <div class="warn">
    &#9888; <strong>Penting:</strong> Segera hapus file <code>install.php</code> setelah berhasil login!
  </div>

  <p style="text-align:center;margin-top:20px"><small>Copyright &copy; 2026 RUMAHIMI &mdash; Sistem Manajemen Kelas</small></p>
</div>
</body>
</html>
<?php

} catch (PDOException $e) {
    ?>
<!DOCTYPE html>
<html lang="id">
<head><meta charset="UTF-8"><title>Error Instalasi</title>
<style>body{font-family:Arial,sans-serif;background:#fff0f0;padding:40px}div{max-width:560px;margin:0 auto;background:#fee2e2;border:1px solid #fca5a5;border-radius:12px;padding:28px}h2{color:#dc2626}code{background:#1e293b;color:#f87171;padding:2px 8px;border-radius:4px}ul{line-height:2;font-size:14px}</style>
</head><body>
<div>
  <h2>&#10060; Instalasi Gagal</h2>
  <p><strong>Error:</strong> <?= htmlspecialchars($e->getMessage()) ?></p>
  <p><strong>Kemungkinan penyebab:</strong></p>
  <ul>
    <li>XAMPP MySQL belum dijalankan &rarr; buka XAMPP Control Panel, klik <strong>Start</strong> pada MySQL</li>
    <li>Password MySQL salah &rarr; edit baris <code>$pass = '';</code> di file <code>install.php</code> ini</li>
    <li>User MySQL bukan <code>root</code> &rarr; edit baris <code>$user = 'root';</code></li>
  </ul>
  <p>Setelah diperbaiki, refresh halaman ini.</p>
</div>
</body></html>
<?php
}
