<?php
session_start();
require_once __DIR__ . '/includes/config.php';

if (isLoggedIn()) {
    header('Location: ' . ($_SESSION['role']==='admin' ? BASE_URL.'admin/index.php' : BASE_URL.'guru/index.php'));
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $username = trim($_POST['username'] ?? '');
    $password = $_POST['password'] ?? '';

    if ($username && $password) {
        $db   = getDB();
        $stmt = $db->prepare('SELECT * FROM users WHERE username = ? LIMIT 1');
        $stmt->execute([$username]);
        $user = $stmt->fetch();

        if ($user && password_verify($password, $user['password'])) {
            // Login berhasil
            $_SESSION['user_id']       = $user['id'];
            $_SESSION['nama']          = $user['nama'];
            $_SESSION['username']      = $user['username'];
            $_SESSION['role']          = $user['role'];
            $_SESSION['is_walas']      = $user['is_walas'];
            $_SESSION['kelas_wali_id'] = $user['kelas_wali_id'];
            header('Location: ' . ($user['role']==='admin' ? BASE_URL.'admin/index.php' : BASE_URL.'guru/index.php'));
            exit;
        } else {
            $error = 'Username atau password salah.';
        }
    } else {
        $error = 'Username dan password harus diisi.';
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
  <meta name="mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="theme-color" content="#0f172a">
  <title>Login &mdash; <?= APP_NAME ?></title>
  <link rel="icon" href="assets/img/logo.png">
  <link rel="stylesheet" href="assets/css/style.css?v=2">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
</head>
<body>
<div class="login-page">
  <!-- Kiri -->
  <div class="login-left">
    <div style="text-align:center;max-width:420px">
      <img src="<?= BASE_URL ?>assets/img/logo.png" alt="SiKelas" class="login-logo"
           onerror="this.style.background='rgba(255,255,255,.15)'">
      <div class="login-title">SiKelas</div>
      <div class="login-sub">Sistem Manajemen Kelas</div>
      <div class="login-features">
        <div class="login-feature"><div class="login-feature-icon">&#128218;</div><div class="login-feature-title">Jadwal Pelajaran</div><div class="login-feature-desc">Kelola jadwal tiap kelas</div></div>
        <div class="login-feature"><div class="login-feature-icon">&#9989;</div><div class="login-feature-title">Presensi Digital</div><div class="login-feature-desc">Absensi per mata pelajaran</div></div>
        <div class="login-feature"><div class="login-feature-icon">&#128221;</div><div class="login-feature-title">Jurnal Mengajar</div><div class="login-feature-desc">Dokumentasi pembelajaran</div></div>
        <div class="login-feature"><div class="login-feature-icon">&#128202;</div><div class="login-feature-title">Rekap Nilai</div><div class="login-feature-desc">Analisis nilai siswa</div></div>
      </div>
    </div>
  </div>

  <!-- Kanan -->
  <div class="login-right">
    <div class="login-box">
      <h2>Selamat Datang</h2>
      <p>Masuk ke akun Anda</p>

      <?php if ($error): ?>
      <div class="alert alert-error">
        <i class="fas fa-exclamation-circle"></i> <?= htmlspecialchars($error) ?>
      </div>
      <?php endif; ?>

      <form method="POST" autocomplete="off">
        <div class="form-group">
          <label class="form-label">Username</label>
          <input type="text" name="username" class="form-control"
                 placeholder="Masukkan username"
                 value="<?= htmlspecialchars($_POST['username'] ?? '') ?>"
                 required autofocus autocomplete="username">
        </div>
        <div class="form-group">
          <label class="form-label">Password</label>
          <div class="pass-wrap">
            <input type="password" name="password" id="passInput" class="form-control"
                   placeholder="Masukkan password" required autocomplete="current-password">
            <button type="button" class="pass-toggle" id="passToggle"
                    onclick="togglePass('passInput','passToggle')">
              <i class="fas fa-eye"></i>
            </button>
          </div>
        </div>

        <button type="submit" class="btn btn-primary"
                style="width:100%;justify-content:center;padding:12px;font-size:15px">
          <i class="fas fa-sign-in-alt"></i> Masuk
        </button>
      </form>

      <div class="login-demo">
        <strong>Akun Default:</strong><br>
        Admin &nbsp;: <code>admin</code> / <code>admin123</code><br>
        <small style="color:#94a3b8">(Jalankan install.php terlebih dahulu)</small>
      </div>

      <div style="margin-top:14px;text-align:center">
        <a href="reset_password.php" style="font-size:12px;color:#94a3b8;text-decoration:none">
          &#128272; Lupa password? Reset di sini
        </a>
      </div>

      <div class="login-footer"><?= COPYRIGHT ?></div>
    </div>
  </div>
</div>
<script src="assets/js/app.js"></script>
</body>
</html>
