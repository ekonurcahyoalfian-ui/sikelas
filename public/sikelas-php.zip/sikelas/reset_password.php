<?php
// ============================================================
//  SiKelas - Reset Password Admin Darurat
//  Gunakan file ini jika lupa password admin
//  HAPUS file ini setelah selesai digunakan!
// ============================================================

$host = 'localhost';
$user = 'root';
$pass = '';   // Sesuaikan jika perlu

$msg     = '';
$msgType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $newPass  = trim($_POST['new_password']  ?? '');
    $konfirm  = trim($_POST['confirm_password'] ?? '');
    $kunci    = trim($_POST['kunci'] ?? '');

    // Kunci keamanan sederhana agar tidak sembarang orang bisa reset
    if ($kunci !== 'sikelasreset') {
        $msg     = 'Kunci keamanan salah! Isi dengan: sikelasreset';
        $msgType = 'error';
    } elseif (strlen($newPass) < 6) {
        $msg     = 'Password minimal 6 karakter.';
        $msgType = 'error';
    } elseif ($newPass !== $konfirm) {
        $msg     = 'Konfirmasi password tidak cocok.';
        $msgType = 'error';
    } else {
        try {
            $pdo = new PDO(
                "mysql:host=$host;dbname=sikelas;charset=utf8mb4",
                $user, $pass,
                [PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION]
            );
            $hash = password_hash($newPass, PASSWORD_DEFAULT);

            // Cek apakah admin sudah ada
            $cek = $pdo->query("SELECT id FROM users WHERE username='admin' LIMIT 1")->fetchColumn();
            if ($cek) {
                $pdo->prepare("UPDATE users SET password=? WHERE username='admin'")->execute([$hash]);
                $msg = 'Password admin berhasil direset! Silakan login dengan password baru.';
            } else {
                // Buat akun admin baru jika belum ada
                $pdo->prepare("INSERT INTO users (nama, username, password, role) VALUES ('Administrator', 'admin', ?, 'admin')")->execute([$hash]);
                $msg = 'Akun admin berhasil dibuat! Silakan login.';
            }
            $msgType = 'success';
        } catch (PDOException $e) {
            $msg     = 'Koneksi database gagal: ' . htmlspecialchars($e->getMessage());
            $msgType = 'error';
        }
    }
}
?>
<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Reset Password Admin &mdash; SiKelas</title>
  <style>
    *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
    body {
      font-family: 'Segoe UI', Arial, sans-serif;
      background: linear-gradient(135deg, #0f172a 0%, #1e3a5f 60%, #0f4c2a 100%);
      min-height: 100vh;
      display: flex;
      align-items: center;
      justify-content: center;
      padding: 20px;
    }
    .card {
      background: #fff;
      border-radius: 20px;
      padding: 36px 32px;
      width: 100%;
      max-width: 420px;
      box-shadow: 0 20px 60px rgba(0,0,0,.3);
    }
    .logo-wrap { text-align: center; margin-bottom: 24px; }
    .logo-wrap img { width: 64px; border-radius: 14px; background: #f1f5f9; padding: 6px; }
    .logo-wrap h1 { font-size: 22px; font-weight: 800; color: #1e293b; margin-top: 8px; }
    .logo-wrap p  { font-size: 13px; color: #64748b; margin-top: 2px; }
    .badge-warn {
      background: #fef3c7; border: 1px solid #fcd34d; border-radius: 10px;
      padding: 10px 14px; font-size: 12px; color: #92400e;
      margin-bottom: 20px; display: flex; gap: 8px; align-items: flex-start;
    }
    label { display: block; font-size: 13px; font-weight: 500; color: #334155; margin-bottom: 5px; }
    .req { color: #dc2626; }
    input {
      width: 100%; padding: 10px 14px; border: 1px solid #e2e8f0;
      border-radius: 10px; font-size: 13px; color: #1e293b;
      outline: none; transition: border .15s, box-shadow .15s;
      margin-bottom: 14px;
    }
    input:focus { border-color: #059669; box-shadow: 0 0 0 3px rgba(5,150,105,.12); }
    .hint { font-size: 11px; color: #94a3b8; margin-top: -10px; margin-bottom: 14px; }
    .btn {
      width: 100%; padding: 12px; background: #059669; color: #fff;
      border: none; border-radius: 12px; font-size: 15px; font-weight: 600;
      cursor: pointer; transition: background .15s;
    }
    .btn:hover { background: #047857; }
    .alert {
      padding: 12px 16px; border-radius: 10px; font-size: 13px;
      margin-bottom: 18px; display: flex; gap: 8px; align-items: flex-start;
    }
    .alert-success { background: #d1fae5; border: 1px solid #6ee7b7; color: #065f46; }
    .alert-error   { background: #fee2e2; border: 1px solid #fca5a5; color: #991b1b; }
    .divider { border: none; border-top: 1px solid #f1f5f9; margin: 20px 0; }
    .back-link { display: block; text-align: center; margin-top: 18px; font-size: 13px; color: #059669; text-decoration: none; }
    .back-link:hover { text-decoration: underline; }
    footer { text-align: center; font-size: 11px; color: #94a3b8; margin-top: 20px; }
  </style>
</head>
<body>
<div class="card">
  <div class="logo-wrap">
    <img src="assets/img/logo.png" alt="SiKelas" onerror="this.style.display='none'">
    <h1>SiKelas</h1>
    <p>Reset Password Admin</p>
  </div>

  <div class="badge-warn">
    &#9888;&nbsp;<span><strong>Perhatian:</strong> Hapus file <code>reset_password.php</code> setelah selesai digunakan!</span>
  </div>

  <?php if ($msg): ?>
  <div class="alert alert-<?= $msgType ?>">
    <?= $msgType === 'success' ? '&#10003;' : '&#10005;' ?> <?= $msg ?>
  </div>
  <?php if ($msgType === 'success'): ?>
  <a href="login.php" class="btn" style="display:block;text-align:center;text-decoration:none">
    &#8594; Buka Halaman Login
  </a>
  <hr class="divider">
  <?php endif; ?>
  <?php endif; ?>

  <form method="POST">
    <div>
      <label>Kunci Keamanan <span class="req">*</span></label>
      <input type="text" name="kunci" placeholder="Isi: sikelasreset" required autocomplete="off">
      <p class="hint">Ketik persis: <strong>sikelasreset</strong></p>
    </div>
    <div>
      <label>Password Baru <span class="req">*</span></label>
      <input type="password" name="new_password" placeholder="Minimal 6 karakter" required>
    </div>
    <div>
      <label>Konfirmasi Password <span class="req">*</span></label>
      <input type="password" name="confirm_password" placeholder="Ulangi password baru" required>
    </div>
    <button type="submit" class="btn">&#128272; Reset Password Admin</button>
  </form>

  <a href="login.php" class="back-link">&larr; Kembali ke Login</a>
  <footer>Copyright &copy; 2026 RUMAHIMI &mdash; Sistem Manajemen Kelas</footer>
</div>
</body>
</html>
